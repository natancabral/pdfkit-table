const fs = require("fs");
const PDFDocument = require("../index");


;(async function(){

let doc = new PDFDocument({ margin: 30, size: 'A4' });
doc.pipe(fs.createWriteStream("./example-11.pdf"));

const table1 = {
  headers: [ "head1" , "head2" ],
  rows: [
    ['Prop1', 'Value1'],
    ['Prop2', 'Value2'],
    ['Prop3', 'Value3'],
    ['Prop4', 'Value4']
  ]
};

const table2 = {
  headers: [
    { label: "head1", property: 'prop' },
    { label: "head2", property: 'value' }
  ],
  datas: [
    {prop: 'Prop1', value: 'Value1'},
    {prop: 'Prop2', value: 'Value2'},
    {prop: 'Prop3', value: 'Value3'},
    {prop: 'Prop4', value: 'Value4'}
  ],
};

const tableOptions1 = {
  prepareRow: (row, indexColumn, indexRow, rectRow) => {
    indexRow === 0 && doc.font("Helvetica").fontSize(22);
  }
};

const tableOptions2 = {
  prepareRow: (row, indexColumn, indexRow, rectRow) => {
    indexRow === 0 && doc.font("Helvetica").fontSize(22);
    if(indexColumn === 0) {
      doc.fillColor('white');
      doc.addBackground(rectRow, (indexRow % 2 ? 'blue' : 'green'), 0.5); 
    }
  }
};

await doc.table(table1, tableOptions1);
await doc.table(table2, tableOptions2);
await doc.table(table2, tableOptions2);

doc.end();

})();

