const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
// const _ = require("underscore");

(async function () {
  // I have multiple tables with dynamic sizes sometimes the table fits in the remaining (restante) space and sometimes dont

  const doc = new PDFDocument({ margin: 30, size: "Letter" });
  doc.pipe(fs.createWriteStream(`./example-7.pdf`));
  doc.fontSize(12);
  // doc.moveDown();

  let tables = [];
  let tableCount = 20;
  for (let i = 0; i < tableCount; i++) {
    let rows = []
    let rowcount = Math.ceil(Math.random() * 20)
    for (let j = 0; j < rowcount; j++) {
        let largeString = 'Hi there'
        let infoCount = Math.ceil(Math.random() * 20)
        for (let k = 0; k < infoCount; k++) {
            largeString += '\n wa'
        }
        let row = [
            i+'AA', 'BB', largeString
        ]
        rows.push(row)
    }

    tables.push({
      headers: ["A", "B", "C"],
      rows,
      options: {
        title: `Title ${i} ...`,
        subtitle: `SubTitle ${i} ...`,
        padding: 5,
      },
    });
  }

  fs.writeFile('./document-7.json', JSON.stringify(tables), (err) => {
    if (err)
      console.log(err);
    else {
    //   console.log("File written successfully\n");
    //   console.log("The written has the following contents:");
    //   console.log(fs.readFileSync("books.txt", ));
    }
  });

  // const tableJson = require("./document-7.json");

  doc.tables(tables);

  // Finalize PDF file
  doc.end();
})();
