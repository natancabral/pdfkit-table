/**
 * You need to install on terminal (node.js):
 * -----------------------------------------------------
 * $ npm install pdfkit-table
 * -----------------------------------------------------
 * Run this file:
 * -----------------------------------------------------
 * $ node index-example.js
 * -----------------------------------------------------
 * 
 */

const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
const doc = new PDFDocument({
  margin: 30, 
});
 
// to save on server
doc.pipe(fs.createWriteStream("./example-14.pdf"));

// -----------------------------------------------------------------------------------------------------
// Simple Table with Array
// -----------------------------------------------------------------------------------------------------
const table = {
  headers: ["Country Country Country", "Conversion rate", "Trend"],
  rows: [
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
  ],
};
const options = {
  width: 300,
  x: 100,
  y: 0,
  padding: {
    top: 10, bottom: 10, left: 5, right: 5, 
  }
};
doc.fontSize(9).font('Helvetica');
doc.table( table, options).then( () => {
  doc.end();
});
// A4 595.28 x 841.89 (portrait) (about width sizes)
 
 // if your run express.js server:
 // HTTP response only to show pdf
 // doc.pipe(res);
 
 // done
 
