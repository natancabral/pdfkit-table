const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("pdfkit-table");


;(async function(){

let doc = new PDFDocument({ margin: 30, size: 'A5' });
doc.pipe(fs.createWriteStream("./example-13.pdf"));

// table
const table = {
  title: "Title",
  subtitle: "Subtitle",
  headers: ["Country", "Conversion rate", "Trend"],
  rows: [
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
  ],
};

// set font file
let localType = "./font/Montserrat-Regular.ttf";

// see options
doc.table( table, { 
  width: 300,
  prepareHeader: () => doc.font(localType).fontSize(8),
  prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {
    doc.font(localType).fontSize(8);
  },
}); 

doc.moveDown();

// table 2
const table2 = {
  title: { label: 'Title Object 2', fontSize: 30, color: 'blue', fontFamily: localType },
  subtitle: "Subtitle 2",
  headers: ["Country 2", "Conversion rate 2", "Trend 2"],
  rows: [
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
  ],
};

// see options 2
doc.table( table2, { 
  width: 350,
  prepareHeader: () => doc.font(localType).fontSize(8),
  prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {
    doc.font(localType).fontSize(8);
  },
}); 

doc.end();

})();

