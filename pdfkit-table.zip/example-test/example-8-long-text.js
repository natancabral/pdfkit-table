const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
// const _ = require("underscore");

;(async function(){

  // Problem with long text in cell spreading on several pages

  let doc = new PDFDocument({ margin: 30, size: 'A4' });
  doc.pipe(fs.createWriteStream("./example-8-long-text.pdf"));

  const lorem = `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.`;
  let longtext = "";
  for(let i = 0; i < 25; i++) {
   longtext += `${i + 1}. ${lorem}\n`;
  }

  const table = {
    headers: [ "Name", "Description" ],
    rows: [
        [ "Name 1", longtext ],
        [ 'Name 2', '########## --------------.' ],
        [ 'Name 3', longtext ],
        [ 'Name 4', '########## --------------.' ],
    ]
  };

  // await doc.table(table,{});

  doc.fontSize(8);
  const text1 = `This text is left aligned. ${longtext}`;
  const text2 = `This text is left aligned. ${String(longtext).substring(0,1000)}`;
  const optionsText = { width: 410, align: 'left', x: 100};

  // ----

  let calc = doc.heightOfString(text1, optionsText);
  let posY = doc.page.height - (doc.page.margins.top + doc.y + calc);
  let getPos = {x: doc.x, y: doc.y, };

  doc.rect(getPos.x, getPos.y, 410, calc).stroke();
  doc.text(text1, optionsText);
  doc.moveDown();

  // ----

  calc = doc.heightOfString(text2, optionsText);
  posY = doc.page.height - (doc.page.margins.top + doc.y + calc);
  getPos = {x: doc.x, y: doc.y, };

  doc.rect(getPos.x, getPos.y, 410, calc).stroke();
  doc.text(text2, optionsText);  
  doc.moveDown();

  // doc.x = doc.page.margins.left;
  // doc.y = (posY < 0 ? posY * -1 : posY) + doc.page.margins.top;

  doc.text('Position', { 
      width: 410,
      align: 'left',
    }
  );

  doc.end();

})();