/**
 * You need to install on terminal (node.js):
 * -----------------------------------------------------
 * $ npm install pdfkit-table
 * -----------------------------------------------------
 * Run this file:
 * -----------------------------------------------------
 * $ node index-example.js
 * -----------------------------------------------------
 * 
 */

const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");

const json = require("./table-large.json");

;(async function(){

  // create document
  const doc = new PDFDocument({ margin: 30, });
  // to save on server
  doc.pipe(fs.createWriteStream(`./example-3.pdf`));

  // Array.isArray(json) && json.forEach( table => doc.table( table, table.options || {} ) );
  Array.isArray(json) && json.forEach( async table => await doc.table( table, {
      padding: 2,
      prepareHeader: () => doc.fillColor('blue').font("Helvetica-Bold").fontSize(13)
    })
  );

  await doc.tables( json, () => {
    // if your run express.js server:
    // HTTP response only to show pdf
    // doc.pipe(res);
    // done
    doc.end();
  });

})();