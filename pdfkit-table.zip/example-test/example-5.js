const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
// const _ = require("underscore");

;(async function(){

  // create document
  const doc = new PDFDocument({ margin: 30, });

  // to save on server
  doc.pipe(fs.createWriteStream(`./example-5.pdf`));

  const table01 = {
   "headers" : ["A", "B", "C"],
    "rows": [
        [ "Version 0.1.74", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id est ipsum. Fusce scelerisque maximus justo, lacinia ornare felis iaculis nec.", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id est ipsum. " ],
        [ "Update:", "Age 2", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id est ipsum. Fusce." ],
        [ "$ npm pdfkit-table@latest", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id est ipsum.", "Year 3" ],
        [ "Thanks", "Age 4", "Year 4" ],
    ],
  };

  await doc.table(table01, {
    columnSpacing: 10,
    padding: 10,
    columnsSize: [200, 220, 135],
    align: "center",
    prepareHeader: () => doc.fontSize(11), // {Function}
    prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {

      const {x, y, width, height} = rectCell;

      // first line 
      if(indexColumn === 0){
        doc
        .lineWidth(.5)
        .moveTo(x, y)
        .lineTo(x, y + height)
        .stroke();  
      }

      doc
      .lineWidth(.5)
      .moveTo(x + width, y)
      .lineTo(x + width, y + height)
      .stroke();


      doc.fontSize(10).fillColor('#292929');

    }, // {Function}
  });

  // if your run express.js server:
  // HTTP response only to show pdf
  // doc.pipe(res);

  // done
  doc.end();

})();