/**
 * You need to install on terminal (node.js):
 * -----------------------------------------------------
 * $ npm install pdfkit-table
 * -----------------------------------------------------
 * Run this file:
 * -----------------------------------------------------
 * $ node index-example.js
 * -----------------------------------------------------
 * 
 */

const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
const doc = new PDFDocument({
  margin: 30, 
});
 
// to save on server
doc.pipe(fs.createWriteStream("./example-15.pdf"));

const table = {
  headers: ["Country Country Country", "Conversion rate", "Trend"],
  rows: [
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
  ],
};


const table = { 
  title: '', 
  headers: [ 
    { property: 'page', label: 'Page', align: 'center', headerOpacity: OPACITY, }, 
    { property: 'sku', label: 'Item no', headerOpacity: OPACITY }, 
    { property: 'barcode', label: 'Item Barcode', headerOpacity: OPACITY, 
    renderer: (value, indexColumn, indexRow, row, rectRow, rectCell) => { 
      const { x, y, width, height } = rectCell; 
      if (row.barCodePng) { 
        doc.image(row.barCodePng, x, y + 5, { fit: [60, 22], align: 'center', valign: 'center' }) 
      } 
      return '' 
    } }, 
    { property: 'itemDescription', label: 'Item Description', headerOpacity: OPACITY }, 
    { property: 'packageQuantity', align: 'center', label: 'Packed Per', headerOpacity: OPACITY }, 
    { property: 'costPrice', align: 'right', label: 'Cost Price', headerOpacity: OPACITY }, 
    { property: 'retailPrice', align: 'right', label: 'Rec. Retail Price', headerOpacity: OPACITY } 
  ], 
  datas: datas, 
  rows: [ ], 
}


const options = {
  width: 300,
  x: 100,
  y: 0,
  padding: {
    top: 10, bottom: 10, left: 5, right: 5, 
  }
};
doc.fontSize(9).font('Helvetica');
doc.table( table, options).then( () => {
  doc.end();
});
// A4 595.28 x 841.89 (portrait) (about width sizes)
 
 // if your run express.js server:
 // HTTP response only to show pdf
 // doc.pipe(res);
 
 // done
 
