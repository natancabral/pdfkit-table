const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("pdfkit-table");


;(async function(){

let doc = new PDFDocument({ margin: 30, size: 'A4' });
doc.pipe(fs.createWriteStream("./example-12.pdf"));

const table1 = {
  headers: [ "head1" , "head2" ],
  // headers: [],
  rows: [
    [ 'Prop1', 'Value1' ],
    [ 'Prop2', 'Value2' ],
    [ 'Prop3', 'Value3' ],
    [ 'Prop4', 'Value4' ]
  ]
};

const table2 = {
  headers: [
    { label: "head1", property: 'prop' },
    { label: "head2", property: 'value' }, 
  ],
  datas: [
    { prop: 'Prop1', value: 'Value1' },
    { prop: 'Prop2', value: 'Value2' },
    { prop: 'Prop3', value: 'Value3' },
    { prop: 'Prop4', value: 'Value4' }
  ],
};

const table3 = {
  headers: [
    { label: "head1", property: 'prop' },
    { label: "head2", property: 'value' }
  ],
  datas: [
    { prop: 'Prop1', value: 'Value1' },
    { prop: 'Prop2', value: 'Value2' },
    { prop: 'Prop3', value: 'Value3' },
    { prop: 'Prop4', value: 'Value4' }
  ],
};

const tableOptionsHide = {
  hideHeader: true,
};

const tableOptions1 = {
  // prepareRow: (row, indexColumn, indexRow, rectRow) => {
  //   indexRow === 0 && doc.font("Helvetica").fontSize(22);
  // }
};

const tableOptions2 = {
  // prepareRow: (row, indexColumn, indexRow, rectRow) => {
  //   indexRow === 0 && doc.font("Helvetica").fontSize(22);
  //   if(indexColumn === 0) {
  //     doc.fillColor('white');
  //     doc.addBackground(rectRow, (indexRow % 2 ? 'blue' : 'green'), 0.5); 
  //   }
  // }
};

await doc.table(table1, {
  hideHeader: true,
});
await doc.table({ ...table2, 
  headers: [
    { label: "head1", property: 'prop' },
    { label: "head2", property: 'value', 
      renderer: (value, indexColumn, indexRow, row, rectRow, rectCell) => { 
        if(indexRow % 2) doc.positionY += 50;
        return value;
      }
    }, 
  ],
}, {
  hideHeader: true,
});
await doc.table(table2, {
  hideHeader: false,
  minRowHeight: 30,
});
await doc.table(table3, {
  hideHeader: true,
});
doc.moveDown();

doc.end();

})();

