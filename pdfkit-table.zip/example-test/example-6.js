const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
// const _ = require("underscore");

;(async function(){

  const filename = "./example-6.pdf";

  // create document
  const doc = new PDFDocument({ margin: 30, });

  // to save on server
  doc.pipe(fs.createWriteStream(filename));

  const tableSample = {
    "headers" : ["A", "B", "C"],
     "rows": [
         [ "Update:", "Age 2", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id est ipsum. Fusce. \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00 \n 00,00" ],
         [ "$ npm pdfkit-table@latest", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id est ipsum.", "Year 3" ],
         [ "Thanks", "Age 4", "Year 4" ],
     ],
   };
 
   const tables = [ tableSample, tableSample, tableSample ];
   Array.isArray(tables) && tables.forEach( (table, index) => {
    if(index) doc.addPage();
    doc.table( table, { 
      title: `Title ${index}` , 
      padding: 5,
      });
   });
 

  // if your run express.js server:
  // HTTP response only to show pdf
  // doc.pipe(res);

  // done
  doc.end();

  // open navigator
  // fs.readFile(filename, (err, data) => {
  //   if(err) throw new Error(err);
  //   res.contentType("application/pdf");
  //   res.send(data)
  // });

})();