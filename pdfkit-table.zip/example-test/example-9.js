const fs = require("fs");
// const PDFDocument = require("pdfkit-table");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
// const _ = require("underscore");

;(async function(){

  // Problem with long text in cell spreading on several pages

  let doc = new PDFDocument({ margin: 30, size: 'A4' });
  doc.pipe(fs.createWriteStream("./example-9.pdf"));

  const table = {
    "headers": [
        { "label": "Name", "property": "name", "width": 150, "headerColor": "#098", "headerOpacity": 1, columnColor: '#098', columnColor: 1 },
        { "label": "Age", "property": "age", "width": 150, "headerColor": "#333333", "headerOpacity": 1 },
        { "label": "Year Func", "property": "year", "width": 150, "headerColor": "#333333", "headerOpacity": 1}
    ],
    "datas": [
      { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
      { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
      { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
      { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
      { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
      { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
      { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
      { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
      { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
      { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
      { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
      { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
      { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
      { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
      { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
      { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
],
    "options": {
        padding: 4,
        "prepareHeader": () => {
            doc
            .opacity(1)
            .fillColor("#ffffff")
            .fontSize(8)
        },
    }
  };

  await doc.table(table,{});
  doc.end();

})();