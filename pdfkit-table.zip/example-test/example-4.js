const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
// const _ = require("underscore");

;(async function(){

  // create document
  const doc = new PDFDocument({ margin: 30, });

  // to save on server
  doc.pipe(fs.createWriteStream(`./example-4.pdf`));

  const table01 = {
    "headers": [
        { "label": "Name", "property": "name", "width": 50, "headerColor": "#098", "headerOpacity": 1, columnColor: '#098', columnColor: 1 },
        { "label": "Age", "property": "age", "width": 50, "headerColor": "#333333", "headerOpacity": 1 },
        { "label": "Year Func", "property": "year", "width": 50, "headerColor": "#333333", "headerOpacity": 1 }
    ],
    "datas": [
        { "name": "Name 1", "age": "Age 1", "year": "Year 1" },
        { "name": "Name 2", "age": "Age 2", "year": "Year 2" },
        { "name": "Name 3", "age": "Age 3", "year": "Year 3" },
        { "name": "Name 4", "age": "Age 4", "year": "Year 4" },
    ],
    "options": {
        padding: 4,
        width: 500,
        "prepareHeader": () => {
            doc
            .opacity(1)
            .fillColor("#ffffff")
            .fontSize(8)
        },
    }
  };

  const tableSimple = {
    headers: ["8CountryX", "Conversion rate", "Trend"],
    rows: [
      ["Switzerland", "12%", "+1.12%"],
      ["France", "67%", "-0.98%"],
      ["England", "33%", "+4.44%"],
      ["Brazil", "88%", "+2.44%"],
    ],
  };


  await doc.table(table01, {...table01.options, y: 30, x: null, divider: {horizontal: {disabled: true}}});
  await doc.table(table01, {y: 30, x: 190, width: 200});
  await doc.table(table01, {y: 30, x: 400, width: 190});

  await doc.table(table01, {...table01.options, y: 130, x: null});
  await doc.table(tableSimple, {y: 130, x: 190, width: 200, divider: {horizontal: {disabled: true}}});
  await doc.table(tableSimple, {y: 130, x: 400, width: 190});

  await doc.table(table01, {...table01.options, y: 250, x: null, absolutePosition: true});
  await doc.table(tableSimple, {y: 250, x: 190, width: 200, absolutePosition: true});
  await doc.table(tableSimple, {y: 250, x: 400, width: 190, absolutePosition: true});

  await doc.table(table01, {...table01.options, y: 400, x: null});
  await doc.table(table01, {y: 400, x: 190, width: 200});
  await doc.table(table01, {y: 400, x: 400, width: 190});

  doc.addPage({ margin: 10});

  await doc.table(table01, {...table01.options, y: 30, x: null, divider: {horizontal: {disabled: true}}});
  await doc.table(table01, {y: 30, x: 190, width: 200});
  await doc.table(table01, {y: 30, x: 400, width: 190});

  await doc.table(table01, {...table01.options, x: null});
  await doc.table(table01, {x: 190, width: 200});
  await doc.table(table01, {x: 400, width: 190});

  await doc.table(table01, {...table01.options, x: null, y: null, divider: {horizontal: {width:2}}})
  await doc.table(table01, {width: 200});
  await doc.table(table01, {width: 190, divider: {horizontal: {width:2, opacity:1}}})

  // if your run express.js server:
  // HTTP response only to show pdf
  // doc.pipe(res);

  // done
  doc.end();

})();