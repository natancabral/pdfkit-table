const fs = require("fs");
// const PDFDocument = require("pdfkit-table");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
// const _ = require("underscore");

;(async function(){

  // Problem with long text in cell spreading on several pages

  let doc = new PDFDocument({ margin: 30, size: 'A4' });
  doc.pipe(fs.createWriteStream("./example-8.pdf"));

  const lorem = `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.`;
  let longtext = "";
  for(let i = 0; i < 20; i++) {
   longtext += `${i + 1}. ${lorem}\n`;
  }

  const table = {
    headers: [ "Name", "Description" ],
    rows: [
        [ "Name 1", longtext ],
        [ 'Name 2', '########## --------------.' ],
        [ 'Name 2.1', '########## --------------.' ],
        [ 'Name 3', longtext ],
        [ 'Name 4', longtext ],
        [ 'Name 5', '########## --------------.' ],
        [ 'Name 5.1', '########## --------------.' ],
        [ 'Name 5.2', '########## --------------.' ],
    ]
  };

  await doc.table(table,{});
  doc.end();

})();