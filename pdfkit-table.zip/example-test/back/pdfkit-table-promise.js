// comming son. 
// version v0.2.0

const PDFDocument = require("pdfkit");
class PDFDocumentWithTables extends PDFDocument {

  pdfkitTableCache = {
    // cache
    headers: {},
    datas: {},
    rows: {},
    options: {},
    // personal
    table: {
      width: 300, // px
      pages: 0,
      lines: 0,
      columns: 0,
      summation: [],
    },
    distanceCorrection: 1.5,
    safelyMarginBottom: 0, 
    safelyPageHeight: 0,
  };

  constructor(option) 
  {
    super(option);
    this.pdfkitTableCache.safelyMarginBottom = (this.page.margins.bottom / 1.5);
    this.pdfkitTableCache.safelyPageHeight = this.page.height - (this.page.margins.bottom); // this.page.margins.top + 
  }

  logg(...args) 
  {
    console.log(args);
  }

  seeTableHeightLimit(height) 
  {
    return (this.y + height + this.pdfkitTableCache.safelyMarginBottom >= this.pdfkitTableCache.safelyPageHeight);
  }

  addPageAsync()
  {
    return new Promise( async (resolve, reject) => 
    {
      try {
        const { layout, size, margins } = this.page;
        await this.addPage({ layout, size, margins });
        resolve(this);          
      } catch (error) {
        reject(error);
      }
    });
  }

  // event emitter
  pageAddedFire()
  {
    this.pdfkitTableCache.table.pages += 1;
    this.initialPositionY = this.page.margins.top;
    this.positionY = this.page.margins.top;
    // this.addPage({
    //   layout: this.page.layout,
    //   size: this.page.size,
    //   margins: this.page.margins,
    // });
    // lockAddHeader || addHeader();
    const { headers, options } = this.pdfkitTableCache;
    this.createHeader({ headers, options });
    return this;
  };

  createRowFill({ x, y, width, height }, fillColor, fillOpacity, callback) 
  {
    this.logg('createRowFill');
    return new Promise((resolve, reject) => 
    {
      try 
      {
        const distance = this.pdfkitTableCache.distanceCorrection; // 1.5 // distance // #TODO padding.top and bottom

        // validate
        fillColor || (fillColor = 'grey');
        fillOpacity || (fillOpacity = 0.1);

        // save current style
        this.save();

        // draw bg
        this
        .fill(fillColor)
        //.stroke(fillColor)
        .fillOpacity(fillOpacity)
        .rect(x, y - (distance * 3), width, height + (distance * 2))
        //.stroke()
        .fill();

        // back to saved style
        this.restore();

        typeof callback === 'function' && callback(this);

        resolve(this);
      } 
      catch (error) 
      {
        console.log(error);
        reject(error);
      }
    });
  }

  createDivider(type, x, y, strokeWidth, strokeOpacity, strokeDisabled)
  {
    // validate
    type || (type = 'horizontal'); // header | horizontal | vertical 
    strokeWidth     = strokeWidth || this.pdfkitTableCache.options.divider[type].width || 0.5;
    strokeOpacity   = strokeOpacity || this.pdfkitTableCache.options.divider[type].opacity || 0.5;
    strokeDisabled  = strokeDisabled || this.pdfkitTableCache.options.divider[type].disabled || false;

    if(strokeDisabled)
    {
      return;
    }
    
    // variables
    const distance = this.pdfkitTableCache.distanceCorrection; // 1.5 // distance // #TODO padding.top and bottom
    const s = (strokeWidth / 2) - distance; // space line and letter
    const m = this.pdfkitTableCache.options.x || this.page.margins.left || 30; // margin
    
    this.logg(distance, s, m, x, y, strokeWidth, strokeOpacity, this.pdfkitTableCache.table.width);

    // save style
    this.save();

    // draw
    this
    .moveTo(x, y + s)
    .lineTo(x + this.pdfkitTableCache.table.width, y + s)
    .lineWidth(strokeWidth)
    .opacity(strokeOpacity)
    .stroke()
    // Reset opacity after drawing the line
    .opacity(1);

    // reset style
    this.restore();

    // add
    this.positionY += strokeWidth + (distance * 2);

    return this;
  }

  async createHeaderArray({ headers, options }) 
  {
    this.logg('createHeaderArray');
    return new Promise( async (resolve, reject) => 
    {      
      // variables
      const { top, right, bottom, left } = this.pdfkitTableCache.options.padding;
      let colIndex; // index
      let colLen = headers.length || 0; // array columns
      let text;

      // x reset
      this.positionX = this.initialPositionX;
      // calc row height
      this.headerHeight || (this.headerHeight = await this.calcRowHeightArray(headers, { cellWidth: this.cellWidth, isHeader: true }));
      // fill header
      this.createRowFill({ x: this.initialPositionX, y: this.positionY, width: this.pdfkitTableCache.table.width, height: this.headerHeight });
      // style
      this.save();
      this.pdfkitTableCache.options.prepareHeader();

      // columns
      for(colIndex = 0; colIndex < colLen; colIndex++) 
      {
        // validade
        text = headers[colIndex];
        this.logg(text, colIndex);
        this.text(text, this.positionX + left, this.positionY + top, 
        {
          width: this.cellWidth - (left + right),
          align: 'left',
        });

        // x add
        this.positionX += this.cellWidth;
      }

      // /!\ dont changer order
      // y add
      this.positionY += this.headerHeight;
      // divider
      this.createDivider('horizontal', this.initialPositionX, this.positionY, 1, 1);
      // style restore
      this.restore();
      // to global
      this.pdfkitTableCache.table.columns = colLen;

      resolve(this);
    });
  }

  createHeaderObject(data) 
  {
    this.logg('createHeaderObject');
    return new Promise((resolve, reject) => 
    {
      const { datas, headers } = data;
      
      datas.forEach((row, elIndex) => {
        this.logg(row);
        headers.forEach((col, heIndex) => {
          this.logg(col);
        });
      });

      // to global
      // this.pdfkitTableCache.table.columns = colLen;

      resolve();
    });
  }

  createHeader({ headers, options }) 
  {
    this.logg('createHeader');
    return new Promise( async (resolve, reject) => 
    {
      // validate
      if(!headers || !headers.length)
      {
        new Error('Please, defined headers. Use hideHeader option to hide header.');
        return;
      }

      // validate
      const isDataArray = headers.length && Array.isArray(headers);

      // rows array
      if(isDataArray)
      {
        await this.createHeaderArray({ headers, options });
      } 
      // datas array
      else 
      {
        await this.createHeaderObject({ headers, options });
      }

      resolve(this);
    });
  }

  createRowArray(data) 
  {
    this.logg('createRowArray');
    return new Promise( async (resolve, reject) => 
    {
      // local
      const { rows, options } = data;

      // has content
      if(!rows || !rows.length)
      {
        resolve();
        return;
      }

      // is array whith object
      if(!Array.isArray(rows[0]) || typeof rows[0][0] !== 'string')
      {
        reject();
        throw new Error('ROWS need be a Array[] with String"". See documentation.');
        return;
      }

      // variables
      const { top, right, bottom, left } = this.pdfkitTableCache.options.padding;
      let rowIndex, colIndex; // index
      let rowLen = rows.length || 0; // array lines
      let colLen = rows[0].length || 0; // array columns
      let elm; // element line
      let text;

      // loop lines
      for(rowIndex = 0; rowIndex < rowLen; rowIndex++) 
      {
        // row calc
        this.rowHeight = await this.calcRowHeightArray(rows[rowIndex], { cellWidth: this.cellWidth });

        // Switch to next page if we cannot go any further because the space is over.
        // For safety, consider 3 rows margin instead of just one
        // this.y + this.rowHeight + this.pdfkitTableCache.safelyMarginBottom >= this.pdfkitTableCache.safelyPageHeight
        if(this.seeTableHeightLimit(this.rowHeight))
        {
          // const { layout, size, margins } = this.page;
          // await this.addPage({ layout, size, margins });
          await this.addPageAsync();
        }

        // x reset
        this.positionX = this.initialPositionX;
        // element
        elm = rows[rowIndex];

        // loop columns
        for(colIndex = 0; colIndex < colLen; colIndex++) 
        {

          // fill cell
          this.createRowFill({ x: this.positionX, y: this.positionY, width: this.cellWidth, height: this.rowHeight }, colIndex % 2 ? 'grey' : 'green', 0.2);
          // style
          this.pdfkitTableCache.options.prepareRow(elm, colIndex, rowIndex, {}, {});

          // validade
          text = elm[colIndex];
          this.logg(text, colIndex);
          this.text(text, this.positionX + left, this.positionY + top,
          {
            width: this.cellWidth - (left + right),
            align: 'left',
          });

          // x add
          this.positionX += this.cellWidth;
        }

        // /!\ dont changer order
        // y add
        this.positionY += this.rowHeight;
        // x reset
        this.positionX = this.initialPositionX;
        // divider
        this.createDivider('horizontal', this.initialPositionX, this.positionY);
      }

      // x reset
      this.positionX = this.initialPositionX;
      // to global
      this.pdfkitTableCache.table.lines = rowLen;

      resolve(this);
    });
  }

  createRowObject(data) 
  {
    this.logg('createRowObject');
    return new Promise((resolve, reject) => 
    {
      // variables
      const { datas, headers } = data;

      // has content
      if(!datas || !datas.length)
      {
        resolve();
        return;
      }

      // is array whith object
      if(Array.isArray(datas[0]) || typeof datas[0] !== 'object')
      {
        reject();
        throw new Error('Datas need be a Array[] with Objects{}. See documentation.');
        return;
      }

      // loop
      datas.forEach((row, elIndex) => {
        this.logg(row);
        headers.forEach((col, heIndex) => {
          this.logg(col);
        });
      });

      // to global
      // this.pdfkitTableCache.table.lines = rowLen;

      resolve();
    });
  }

  async createTable(data) 
  {
    this.logg('createTable');
    return new Promise(async (resolve, reject) => 
    {
      // variables
      const { table, options } = data;
        let { headers, datas, rows } = table;

      // validate
      headers || (headers = []);
      datas || (datas = []);
      rows || (rows = []);

      await this.createRowObject({ headers, datas, options });
      await this.createRowArray({ headers, rows, options });

      resolve(this);
    });
  }

  prepareTable(table) 
  {
    // parse json 
    typeof table === 'string' && (table = JSON.parse(table));

    // validate
    table                       || (table = {});
    table.headers               || (table.headers = []);
    table.datas                 || (table.datas = []);
    table.rows                  || (table.rows = []);
    table.options               || (table.options = {});

    // global
    this.pdfkitTableCache = { ...this.pdfkitTableCache, ...table };

    return table;
  }

  prepareOptions(options) 
  {
    // validate
    options = options           || {};
    options.hideHeader          || (options.hideHeader = false);
    options.padding             || (options.padding);
    options.columnsSize         || (options.columnsSize = []);
    options.addPage             || (options.addPage = false);
    options.absolutePosition    || (options.absolutePosition = false);
    options.minRowHeight        || (options.minRowHeight = 0);
    options.width               || (options.width = 300);

    // validate padding
    options.padding = this.prepareCellPadding(options.padding);

    // divider lines
    options.divider             || (options.divider             = {});
    options.divider.header      || (options.divider.header      = { disabled: false, width: undefined, opacity: undefined });
    options.divider.horizontal  || (options.divider.horizontal  = { disabled: false, width: undefined, opacity: undefined });
    options.divider.vertical    || (options.divider.vertical    = { disabled: true, width: undefined, opacity: undefined });

    // prepare style
    options.prepareHeader       || (options.prepareHeader = () => this.fillColor('black').font("Helvetica-Bold").fontSize(8).fill());
    options.prepareRow          || (options.prepareRow = (row, indexColumn, indexRow, rectRow, rectCell) => this.fillColor('black').font("Helvetica").fontSize(8).fill());
    //const prepareCell      = options.prepareCell || ((cell, indexColumn, indexRow, indexCell, rectCell) => this.fillColor('black').font("Helvetica").fontSize(8).fill());

    // global
    this.pdfkitTableCache.options = options;
    this.pdfkitTableCache.table || (this.pdfkitTableCache.table = {})

    // init
    this.initialPositionX       = this.pdfkitTableCache.options.x   || this.x;
    this.positionX              = this.pdfkitTableCache.options.x   || this.x;
    this.positionY              = (this.pdfkitTableCache.options.y  || this.y) + (this.pdfkitTableCache.distanceCorrection * 2);

    // ------------------------------------------------------------------------
    // remove after
    // ------------------------------------------------------------------------
    // global
    this.rowHeight = null;
    this.cellWidth = 100; // array
    this.pdfkitTableCache.table.width || (this.pdfkitTableCache.table.width = options.width); // remove after
    // ------------------------------------------------------------------------
    // ------------------------------------------------------------------------

    return options;
  }

  prepareCellPadding(p)
  {
    // padding: [10, 10, 10, 10]
    // padding: [10, 10]
    // padding: {top: 10, right: 10, bottom: 10, left: 10}
    // padding: 10,
    // array
    if(Array.isArray(p)){
      switch(p.length){
        case 3: p = [...p, 0]; break;
        case 2: p = [...p, ...p]; break;
        case 1
        : p = Array(4).fill(p[0]); break;
      }
    }
    // number
    else if(typeof p === 'number'){
      p = Array(4).fill(p);
    }
    // object
    else if(typeof p === 'object'){
      const {top, right, bottom, left} = p;
      p = [top, right, bottom, left];
    } 
    // null
    else {
      p = Array(4).fill(0);
    }
    // resolve
    return {
      top:    p[0] >> 0, // int
      right:  p[1] >> 0, 
      bottom: p[2] >> 0, 
      left:   p[3] >> 0,
    };
  };

  calcRowHeightArray(row, {cellWidth, align, isHeader})
  {
    return new Promise((resolve, reject) => 
    {

          // criar um padding para header  ???/
    // cellp = this.prepareCellPadding(this.pdfkitTableCache.headers[i].padding || this.pdfkitTableCache.options.padding || 0);

    isHeader === undefined && (isHeader = false);

    // variables
    let text = '';
    let height = isHeader ? 0 : (this.pdfkitTableCache.minRowHeight || 0);
    let heightCompute = 0;
    let len = row.length || 0;
    let i = 0;

    // validate
    const { left, top, right, bottom } = this.pdfkitTableCache.options.padding;

    // loop
    for(i = 0; i < len; i++) 
    {
      // value
      text = row[i];
      text = String(text).replace('bold:','').replace('size','').replace(/^:/g,'');

      // calc height size of string
      heightCompute = this.heightOfString(text, {
        width: cellWidth - (left + right),
        align: align || 'left',
      });
      
      // stay max height
      height = Math.max(height, heightCompute);
    }
    
    // minimum row height 
    // height = Math.max(height, this.pdfkitTableCache.minRowHeight || 0);

    resolve(height + this.pdfkitTableCache.distanceCorrection + top + bottom);
    return height + this.pdfkitTableCache.distanceCorrection + top + bottom;

    });
  };

  calcRowHeightObject(row, cellWidth)
  {
    let result = 0;
    let cellp;

    // if row is object, content with property and options
    if(!Array.isArray(row) && typeof row === 'object' && !row.hasOwnProperty('property')){
      const cells = []; 
      // get all properties names on header
      this.pdfkitTableCache.headers.forEach(({property}) => cells.push(row[property]) );
      // define row with properties header
      row = cells;
    }

    row.forEach((cell,i) => {
      let text = cell;
      // object
      // read cell and get label of object
      if( typeof cell === 'object' ){
        // define label
        text = String(cell.label);
        // apply font size on calc about height row 
        //cell.hasOwnProperty('options') && prepareRowOptions(cell);
      }

      text = String(text).replace('bold:','').replace('size','');
      // cell padding
      cellp = this.prepareCellPadding(this.pdfkitTableCache.headers[i].padding || this.pdfkitTableCache.options.padding || 0);

      // calc height size of string
      const cellHeight = this.heightOfString(text, {
        // width: columnSizes[i] - (cellp.left + cellp.right),
        width: this.cellWidth - (cellp.left + cellp.right),
        align: 'left',
      });
      result = Math.max(result, cellHeight);
    });

    return result; // + columnSpacing;
  }

  async table(table, options, callback) 
  {
    // prepare
    table   = this.prepareTable(table);
    options = this.prepareOptions(options);
    options = { ...options, ...table.options }; // merge options

    // on fire
    this.on('pageAdded', this.pageAddedFire);

    // init
    this.logg('table');
    try 
    {
      await this.createHeader({ headers: table.headers, options });
      await this.createTable({ table, options });
    } 
    catch (error) 
    {
      console.error(error);
      throw new Error(error);
    }

    // off fire
    this.off('pageAdded', this.pageAddedFire);

    // summation: [ 0, 10, 11 ], // colunas com números são somadas
    // summation: 'allowAdditionColumn: true',
    const resolve = {
      ...this.pdfkitTableCache.table,
      y: this.positionY,
      x: this.positionX,
    };

    this.logg(resolve);

    Promise.resolve(resolve);
    typeof callback === 'function' && callback(resolve);

    return this;
  }

  async tables(tables, callback) {
    return new Promise((resolve, reject) => 
    {
      try 
      {
        // if tables is Array
        Array.isArray(tables) ?
        // for each on Array
        tables.forEach( async table => await this.table(table, table.options || {} )) :
        // else is tables is a unique table object
        typeof tables === 'object' && this.table(tables, tables.options || {}) ;
        // callback
        typeof callback === 'function' && callback(this);
      } catch (error) {
        reject(error);
      }
    });
  }

}

module.exports = PDFDocumentWithTables;