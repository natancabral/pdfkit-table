/**
 * You need to install on terminal (node.js):
 * -----------------------------------------------------
 * $ npm install pdfkit-table
 * -----------------------------------------------------
 * Run this file:
 * -----------------------------------------------------
 * $ node index-example.js
 * -----------------------------------------------------
 * 
 */

const fs = require("fs");
const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
const json = require("./table.json");

;(async function(){

  // create document
  const doc = new PDFDocument({ margin: 30, });
  // to save on server
  doc.pipe(fs.createWriteStream(`./example-2.pdf`));
  
  // -----------------------------------------------------------------------------------------------------
  // Simple Table with Array
  // -----------------------------------------------------------------------------------------------------
  const tableArray = {
    title: 'Lorem ipsum dolor sit amet Month % (column size defined)',
    headers: ["CountryX", "Conversion rate", "Trend"],
    rows: [
      ["Switzerland", "12%", "+1.12%"],
      ["France", "67%", "-0.98%"],
      ["England", "33%", "+4.44%"],
      ["Brazil", "88%", "+2.44%"],
    ],
  };
  await doc.table( tableArray, { 
    columnsSize: [150,150,100], 
    columnSpacing: 15,
    //rowSpacing: 15,
    //padding: 15,
    prepareRow: (row, indexColumn, indexRow, rectRow) => {
      doc.font("Helvetica").fontSize(8);
      indexColumn === 0 && doc.addBackground(rectRow,'blue',0.3);
    }, 
  }); // A4 595.28 x 841.89 (portrait) (about width sizes)
  
  doc.moveDown(); // separate tables
  await doc.table( tableArray, { 
    
    width: 400, 
    subtitle: 'Lorem ipsum dolor sit amet',
    x: 100,
    // padding: 15,
  
    prepareRow: (row, indexColumn, indexRow, rectRow) => {
      indexColumn === 0 && doc.addBackground(rectRow, (indexRow % 2 ? 'red' : 'green') ,0.5);
      doc.font("Helvetica").fontSize(8);
    },
  
  }); // A4 595.28 x 841.89 (portrait) (about width sizes)
  
  // move to down
  doc.moveDown(); // separate tables
  
  Array.isArray(json) && json.forEach( async table => await  doc.table( table, table.options || {} ) );
  
  const tableJson = `{ 
    "title": "Title",
    "subtitle": "Subtitle",
    "headers": [
      { "label":"Name", "property":"name", "width":100, "background": {"color": "blue", "opacity": 0.5}, "padding": 5 },
      { "label":"Age", "property":"age", "width":100 },
      { "label":"Year Func", "property":"year", "width":100, "renderer": "function(value, i, e){ return value + '('+(1+2)+')'; }" }
    ],
    "datas": [
      { "name":"Name 1", "age":"Age 1", "year":"Year 1" },
      { "name":"Name 2", "age":"Age 2", "year":"Year 2" },
      { "name":"Name 3", "age":"Age 3", "year":"Year 3" }
    ],
    "rows": [
      ["Name 4", "Age 4", "Year 4"],
      ["Name 5", "Age 5", "Year 5"]
    ],
    "options": {
      "padding": 10,
      "width": 300,
      "x": null, 
      "title": "Json Table",
      "subtitle": "Json Table"
    }
  }`
  await doc.table( tableJson );
  
  const tableJson2 = `{ 
    "headers": ["Name_","Age_","Year_"],
    "rows": [
      ["Name 4", "Age 4", "Year 4"],
      ["Name 5", "Age 5", "Year 5"]
    ],
    "options": {
      "padding": 10,
      "title":"Lorem ipsum dolor sit amet Month %",
      "columnsSize": [50, 50, 100]
    }
  }`
  await doc.table( tableJson2 );
  
  const base64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIwAAAB9CAYAAABwDouCAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABEBJREFUeNrsnc1OU0EUgOf2SsMO9QFo8AH40T227DWgaxVhr9EHUPQBJMBaIrBWjOwBu1eRB/CHB1C7a2hIPWMmMSIFLtzenpn5vmTShkBnOnycMzOdGZJ2u20ATkuCMIAwgDCAMIAwgDAACAMIAwgDCAMIAwgDgDCAMIAwgDCAMIAwAAgDCAMIAwgDCAOAMIAwgDCAMFro6+u7JQ9VKSNSxjt8W13KZynbrVbrDcJERn9//6WDg4NH8vSBlIGMP96Qspim6Xyz2fyJMOFHlMfy8OQMohwlznOJOC8QJtyo8vaYtHNW6hJtJmOJNlEIUy6Xr8r73MwhqnSMNkmSTOzv739EGGRBmliEcWloR54OFlTlnqSn0ZDTUynkvwaRZaVAWSyDrk4ijIezIbu+8rpH1d8Odb0mZGG+Fxxd/klNIkyFlOSPLDM9lOVPanJtIMJ4Ioxdxh/ucTN2JcqMIIx+WYbk4YuS5lwRab6SknRToy0Ik4UqbUGYLFRoC8IAg96uDXpVvSEZ9CZEGN3s0RaEycI32oIwgDBd4z1tQZgs7NAWZkmnxm2a+qGhLWmaXg5tM1VwEcb9gjYUNGUjxJ13oQ5652kDKSkTbKAiwmRlOtK6iTDniDLv5OFG0WMXiS43EcbfGZPdwDRQUJUNmRkNhXzMJJaDbB8K6cwkuRb6QbbgPxpwv8DZAqqa5ahsWOMZu4v/ZbdkkXHLcgz9GNV1Hy49rec43d6TNDQVQ2SJJiUdTk/27LM8Xcrh5Zbsa8UkS3QR5lCKssdRnkm5k/FH16Q8De34CMJkm3pPmb/33B0+ALdr3P12ElHWY7ymDGEAYQBhAGGAabXiWZCURfsBpJRaAfXVXF2LbgZGhPFEFCvHnPn/elW7C+9h3tPhY6bn9vbwOalvC2H8EsUcIc6r814p5q5EmzYnb58IShzvhXHrKCsm+74Xe5O33S+zLWXrpMjjIomVsirF7nfJumViI03Te76v43gtjPsrXzb57Xepd/h6XreHW0lnfL4w0VthRJZVk31ZXwtrIs1dhCkuBdk0Mmz8ZldSVNW3FOWVMAHJ4q003ggToCxeSuONMEquUu2aNL5c0VryRJbVgGWxDLv3SITJQZZu7sXVhvq9waqFcYtln0xx54p6jV2nGdO8m097SlqISBbj3usCEeZs0cUuw2+aOJnQ+tmTZmHsdV/jkQpTF2GuIwzRxfsoo3UMc9+Ayj5QF2E03VHXazTekacuwrgzQqC0LzSmpElU0dsX6lKStn8u0Wu0/XOLkjJZaiiiu0+0paQxFNHdJ9qEGcUP3X2iTZgKfujuE1WDXsnXv0xcHzaehoYMfC8iDDMkL2dKCIMwCIMw3eOCsr6po4duuB8GEAYQBhAGEAYQBgBhAGEAYQBhAGEAYQAQBhAGEAYQBhAGEAYAYQBhAGEAYQBhABAGEAYQBvTwW4ABAOvBhFnye98hAAAAAElFTkSuQmCC";
  const imageRenderer = (value, indexColumn, indexRow, row, rectRow, rectCell) => {
    const { x, y, width, height } = rectCell;
    // doc.image(base64, x, y, { width: 10, height: 10, fit: [100, 100], align: 'center', valign: 'center'});
    doc.image(base64, x, y, { height: height});
    return `${value}`;
  }
  
  // -----------------------------------------------------------------------------------------------------
  // Complex Table with Object
  // -----------------------------------------------------------------------------------------------------
  // A4 595.28 x 841.89 (portrait) (about width sizes)
  const table = {
    headers: [
      { label:"Name", property: 'name', width: 60, renderer: null, padding: 10 },
      { label:"Description", property: 'description', width: 150, renderer: null, padding: 10 }, 
      { label:"Price 1", property: 'price1', width: 100, renderer: null, backgroundColor: 'green', backgroundOpacity: 0.5 }, 
      { label:"Price 2", property: 'price2', width: 100, renderer: null, background: {color: 'blue', opacity: 0.5} }, 
      { label:"Price 3", property: 'price3', width: 80, renderer: imageRenderer }, 
      { label:"Price 4", property: 'price4', width: 63, renderer: (value, indexColumn, indexRow, row) => { return `U$ ${Number(value).toFixed(2)}` } },
    ],
    datas: [
    { description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean mattis ante in laoreet egestas. ', price1: '$1', price3: '$ 3', price2: '$2', price4: '4', name: 'Name 1', options: { backgroundColor: 'green', backgroundOpacity: 0.5 } },
    { name: 'bold:Name 2', description: 'bold:Lorem ipsum dolor.', price1: 'bold:$1', price3: '$3', price2: '$2', price4: '4', options: { fontSize: 10, separation: true } },
    { name: 'Name 3', description: 'Lorem ipsum dolor.', price1: 'bold:$1', price4: '4.111111', price2: '$2', price3: { label:'PRICE $3', options: { fontSize: 12, backgroundColor: 'red', backgroundOpacity: 0.5 } }, },
    { description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean mattis ante in laoreet egestas. ', price1: '$1', price3: '$ 3', price2: '$2', price4: '4', name: 'Name 1', options: { backgroundColor: 'green', backgroundOpacity: 0.5 } },
    { description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean mattis ante in laoreet egestas. ', price1: '$1', price3: '$ 3', price2: '$2', price4: '4', name: 'Name 1', options: { backgroundColor: 'green', backgroundOpacity: 0.5, separation: true } },
    { name: 'Name 3', description: 'Lorem ipsum dolor.', price1: 'bold:$1', price4: '4.111111', price2: '$2', price3: { label:'PRICE $3', options: { fontSize: 12, separation: true, backgroundColor: 'red', backgroundOpacity: 0.5 }}, },
  ],
    rows: [
      [
        "Apple",
        "Nullam ut facilisis mi. Nunc dignissim ex ac vulputate facilisis.",
        "$ 105,99",
        "$ 105,99",
        "$ 105,99",
        "105.99",
      ],
      [
        "Tire",
        "Donec ac tincidunt nisi, sit amet tincidunt mauris. Fusce venenatis tristique quam, nec rhoncus eros volutpat nec. Donec fringilla ut lorem vitae maximus. Morbi ex erat, luctus eu nulla sit amet, facilisis porttitor mi.",
        "$ 105,99",
        "$ 105,99",
        "$ 105,99",
        "105.99",
      ],
    ],
  };
  
  await doc.table(table, {
    title: 'Image',
    prepareHeader: () => doc.font("Helvetica-Bold").fontSize(8),
    prepareRow: (row, indexColumn, indexRow, rectRow) => {
      if( typeof row === 'object' && Array.isArray(row) === false ){
        if(row.name === 'Name 3'){
          // doc.fillColor('red');
          // doc.font("Helvetica").fontSize(8);
          indexColumn === 0 && doc.addBackground(rectRow,'green',0.3);
          //return;
        } else {
          indexColumn === 0 && doc.addBackground(rectRow,'grey',0.3);
        }
      }
      // doc.fillColor('black');
      doc.font("Helvetica").fontSize(8);
    },
  });
  
  // link
  
  const createLink1 = (value, indexColumn, indexRow, row, rectRow, rectCell) => { 
    // get cell rect
    const {x, y, width, height} = rectCell;
    // set link box in doc. (pdf)
    doc.fill('blue').link( x, y, width, height, value);
    // return value text
    return `${value}`; 
  }
  
  const createLink2 = (value, indexColumn, indexRow, row, rectRow, rectCell) => { 
    const {x, y, width, height} = rectCell;
    doc
    .fillColor('blue')
    .underline( x, y, width, height - 2, { color: '#0000FF' }) // undeline
    .link( x, y, width, height, value)
    return `Link Here`; 
  }
  
  const tableLink = {
    title: 'Table with link',
    subtitle: 'version 0.1.45',
    headers: [
      { label: "Name", property: 'name', width: 100, renderer: null },
      { label: "Website", property: 'url', width: 100, renderer: createLink1 },
      { label: "Link To", property: 'url', width: 100, renderer: createLink2 },
    ],
    datas: [
      { name: 'Google', url: 'https://google.com', },
      { name: 'Duck Duck Go', url: 'https://duckduckgo.com', },
      { name: 'Bing', url: 'https://bing.com', },
    ],
  }
  
  await doc.table( tableLink, { 
    prepareRow: () => {
      doc
      .font("Helvetica")
      .fontSize(8)
      .fillColor('black');
    } 
  }).then(() => {
    // if your run express.js server:
    // HTTP response only to show pdf
    // doc.pipe(res);
    
    // done
    doc.end();
  })
    
})();
