const pdfkit = require("pdfkit-table");
const data = require("../test.json");
const fs = require("fs");
const moment = require("moment");
const { options, moveDown, page } = require("pdfkit");

// Create a document
let doc = new pdfkit({
  margin: 30,
  size: "A4",
  // bufferPages: true,
});

//doc.rect()
doc.rect(0, 0, doc.page.width, doc.page.height).fill("#f7ede4");

doc.pipe(fs.createWriteStream("GeneratedPdf.pdf"));
doc.fill("#f7ede4");


doc.page.margins.bottom = 50

//FOR THERAPIST NOTES IN MULTIPLE PAGES

//Link generation for labtest url

async function LinkForLabtest(r){
  console.log("INSIDE---",r.url)
     
            doc
            .fontSize(10)
            .fillColor("#43536E")
            .text("clickhere", 40, 650,{
              link: r.url,
            });
  
  //console.log("S--------->", s)

}




let str = "";
data.notes.forEach((r) => {
  str += r.text;
  str += "\n";
});

let len = str.split(" ").length;
console.log("Notes word count ", len);

doc.page.margins.top = 120;
let fontDetails = {
  title: 14,
  text: 12,
};

let disclaimerFonnt = 8;
let bookingEmail = "booking@proactiveforher.com";

let address = [
  "MILLENNIAL HEALTHTECH PVT. LTD. No. 610,",
  "12th Main, HAL 2nd Stage, Indiranagar,",
  "Bengaluru, Karnataka - 560038",
  "CIN NO: U85100KA2020PTC137232",
];

let startAt = 40;
let position = 40;
let top = 20;
let pageNumber = 1;

let SecondPage = false;

doc.on("pageAdded", (data) => {
  SecondPage = true;
  doc.rect(0, 0, doc.page.width, doc.page.height).fill("#f7ede4");
  addHeader();
  doc.page.margins.bottom = 50

  doc.page.margins.top = 120;

  addPageFooter(doc);
});

/**
 *
 * @param {*} doc
 * @param {*} text
 * @param {*} x
 * @param {*} y
 * @param {*} font
 */
async function addText(doc, text, x, y = 0, font = 9.5) {
  doc.font("fonts/Open Sans Regular.ttf");
  if (y) {
    doc.fontSize(font).text(text, x, y);
  } else {
    doc.fontSize(font).text(text, x);
  }
}

async function addTitleText(doc, text, x, y = 0, font = 12) {
  doc.font("fonts/TenorSans-Regular.ttf");
  if (y) {
    doc.fontSize(font).text(text, x, y);
  } else {
    doc.fontSize(font).text(text, x);
  }
}

/**
 *
 * @param {*} doc
 * @param {*} text
 * @param {*} x
 * @param {*} y
 * @param {*} img
 * @param {*} fitX
 * @param {*} fitY
 */
async function addImage(doc, text, x, y, img, fitX, fitY) {
  doc.fontSize(font).fillColor(color).text(text, x, y);
  doc.image(img, x, y, {
    fit: [150, 250],
  });
}

function addHeader() {
  doc.image("images/proactive.png", 375, 5, {
    fit: [150, 250],
    // align: 'right',
    // valign:'right'
  });
  doc
    .fontSize(8.5)
    .font("fonts/TenorSans-Regular.ttf")
    .fillColor("#44546F")
    .text("MILLENNIAL HEALTHTECH PVT.LTD.", 380, 50);

  doc
    .fontSize(8)
    .font("fonts/Open Sans Regular.ttf")
    .fillColor("black")
    .text("No.610, 12th Main, HAL 2nd Stage, Indiranagar", 380, 70);

  doc
    .fontSize(8)
    .font("fonts/Open Sans Regular.ttf")
    .fillColor("black")
    .text("Bengaluru, Karnataka - 560038 ", 380, 80);

  doc
    .fontSize(8)
    .font("fonts/Open Sans Regular.ttf")
    .fillColor("black")
    .text("CIN NO: U85100KA2020PTC137232", 380, 95);

  //------------------------------------------Header LeftSide----------------------------------------
  doc.fontSize(11);
  doc
    .fontSize(13)
    .font("fonts/TenorSans-Regular.ttf")
    .fillColor("#44546F")
    .text(`${data.doctor.name}`, 40, 10);
  doc
    .fillColor("black")
    .font("fonts/Open Sans Regular.ttf")
    .fontSize(9)
    .text("MD OBG | MBBS", 40, 30);
  doc.font("fonts/Open Sans Regular.ttf").text("Gynaecology", 40, 45);
  doc.font("fonts/Open Sans Regular.ttf").text("Reg no. TESTNAM123", 40, 60);

  //addUserDetails(data)
  
  
  
}

/**
 * Add CompanyDetails
 */
// function addCompanyDetails() {
//   let y = top;
//   let leftPos = position + 330;
//   doc.image("images/proactive.png", leftPos, 5, {
//     fit: [150, 130],
    
//   });

//   y += 60;
//   let yAxis = 50;
//   for (let i = 0; i < address.length; i++) {
//     let a = address[i];
//     if (i === 0) {
//       addText(doc, a, leftPos, yAxis, 9);
//       y += 20;
//     } else {
//       addText(doc, a, leftPos, yAxis + 10, 8);
//       y += 14;
//       yAxis += 10;
//     }
//   }
// }

/**
 *
 * @param {*} data
 */
function addUserDetails(data) {
  let userDetails = data.order;
  let y = top + 110;
  let lineHeight = 15;
  let column2Pos = position + doc.page.width / 2;

  let bookingDate = moment(userDetails?.startTime).format("DD-MM-YYYY hh:mm a");
  addTitleText(doc, `Patient Details`, position, y, fontDetails.title);
  y += lineHeight + 5;
  addText(doc, `Name: ${userDetails?.customerName} `, position, y);

  addText(doc, `Pronouns: ${userDetails?.customerPronouns}`, column2Pos, y);
  y += lineHeight;
  addText(doc, `Age: ${userDetails?.customerAge} `, position);
  addText(doc, `City: ${userDetails?.customerCity} `, column2Pos, y);
  y += lineHeight;
  addText(doc, `Date of Consultation: ${bookingDate} `, position, y);
  addText(doc, `Concern: ${userDetails.customerConcern}`, column2Pos, y);
}

/**
 *  Add Page Footer
 * @param {*} doc
 */
function addPageFooter(doc) {
  let bottom = doc.page.margins.bottom;
  doc.page.margins.bottom = 0;
  doc.fontSize(8);
  let footerStart = doc.page.height - 50;
  doc.text(
    "Page. " + pageNumber,
    0.5 * (doc.page.width - 100),
    footerStart + 35,
    {
      width: 100,
      align: "center",
      lineBreak: false,
    }
  );

  let pageCenter = doc.page.width / 2;
  let mediaStart = pageCenter - 40;
  let iconSize = 29;
  let socialMedias = [
    {
      icon: "images/whatsapp.png",
      link: "https://api.whatsapp.com/send/?phone=919882080808&text=Hello&app_absent=0",
    },
    {
      icon: "images/gmail.png",
      link: "mailto:bookings@proactiveforher.com",
    },
    {
      icon: "images/instagram.png",
      link: "https://www.instagram.com/proactiveforher",
    },
  ];

  socialMedias.forEach((s, i) => {
    console.log("This is i", i);
    //console.log("Gmail-->", s.icon.link)
    if (i==1){
      doc.image(s.icon, mediaStart + (iconSize * i)-2, footerStart, {
        fit: [18, 17.5],
        link: s.link,
        align: "center",
      });
    }
    else{
      doc.image(s.icon, mediaStart + iconSize * i, footerStart, {
        fit: [15, 15],
        link: s.link,
        align: "center",
      }); 
    }
  
  });

  let website = "https://www.proactiveforher.com/";
  let urlStartPos = pageCenter - website.length * 2;
  doc
    .fontSize(10)
    .fillColor("#43536E")
    .text(website, urlStartPos, footerStart + 20, {
      link: "https://www.proactiveforher.com/",
    });

  // Reset text writer position
  doc.text("", 50, 50);
  doc.page.margins.bottom = bottom;
  

  pageNumber++;
}

/**
 * Populate Notes
 * @param {*} data
 * @param {*} doc
 */

let DietReacallData = [];
data.DeitRecall.forEach((r) => {
  let s = {
    description: r.text,
  };
  DietReacallData.push(s);
});

async function populateDietRecall(data, doc) {
  doc.moveDown(1);

  const DeitTatble = {
    headers: [
      {
        label: "Diet Recall",
        property: "description",
        width: 505,
        renderer: null,
      },
    ],
    // complex data
    datas: DietReacallData,
    options: {
      // divider lines
      divider: {
        header: { disabled: false, width: 0.5, opacity: 0.5 },
        horizontal: { disabled: true, width: 0.5, opacity: 0.5 },
      },
    },
  };

  doc.table(DeitTatble, {
    x: 40,
    prepareHeader: () =>
      doc.font("fonts/TenorSans-Regular.ttf").fontSize(11).fillColor("black"),
    prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {
      doc.font("fonts/Open Sans Regular.ttf").fontSize(9).fillColor("black");
    },
  });
}

let DietRecommendData = [];
data.Diet.forEach((r) => {
  let s = {
    description: r.text,
  };
  DietRecommendData.push(s);
});

async function populateDietRecommended(data, doc) {
  doc.moveDown(1);

  const DeitTatble = {
    headers: [
      {
        label: "Diet Recommendation",
        property: "description",
        width: 505,
        renderer: null,
      },
    ],
    // complex data
    datas: DietRecommendData,
    options: {
      // divider lines
      divider: {
        header: { disabled: false, width: 0.5, opacity: 0.5 },
        horizontal: { disabled: true, width: 0.5, opacity: 0.5 },
      },
    },
  };

  doc.table(DeitTatble, {
    x: 40,
    prepareHeader: () =>
      doc.font("fonts/TenorSans-Regular.ttf").fontSize(11).fillColor("black"),
    prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {
      doc.font("fonts/Open Sans Regular.ttf").fontSize(9).fillColor("black");
    },
  });
}

let LabMedicineData = [];
data.LabMedicine.forEach((r) => {
  let s = {
    description: r.text,
  };
  LabMedicineData.push(s);
});

async function populateLabMedicine(data, doc) {
  doc.moveDown(1);
  const LabMedicinetable = {
    headers: [
      {
        label: "Notes From Conversation & Treatment Advice",
        property: "description",
        width: 505,
        renderer: null,
        backgroundColor: "#f7ede4",
      },
    ],
    // complex data

    datas: LabMedicineData,
    options: {
      // divider lines
      divider: {
        header: { disabled: false, width: 0.5, opacity: 0.5 },
        horizontal: { disabled: true, width: 0.5, opacity: 0.5 },
      },
    },
  };

  doc.table(LabMedicinetable, {
    x: 40,
    prepareHeader: () =>
      doc.font("fonts/TenorSans-Regular.ttf").fontSize(11).fillColor("black"),
    prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {
      doc.font("fonts/Open Sans Regular.ttf").fontSize(9).fillColor("black");
      
    },
  });
}

let NotesData = [];
data.notes.forEach((r) => {
  let s = {
    description: r.text,
  };
  NotesData.push(s);
});

async function populateNotes(data, doc) {
  doc.moveDown(2);
  const Notestable = {
    headers: [
      {
        label: "Notes From Conversation ",
        property: "description",
        width: 505,
        renderer: null,
        backgroundColor: "#f7ede4",
      },
    ],
    

    datas: NotesData,
    options: {
      // divider lines
      divider: {
        header: { disabled: false, width: 0.5, opacity: 0.5 },
        horizontal: { disabled: true, width: 0.5, opacity: 0.5 },
        
      },
    },
  };

  doc.table(Notestable, {
    x: 40,
    prepareHeader: () =>
      doc.font("fonts/TenorSans-Regular.ttf").fontSize(11).fillColor("black"),
    prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {
      doc.font("fonts/Open Sans Regular.ttf").fontSize(9).fillColor("black");
      
    },
  });
}



let DrugData = [];
let i = 1;
data.drugDetails.forEach((r) => {
  let s = {
    No: i,
    Medication: r.Medication,
    Strength: r.Strength,
    Frequency: r.Frequency,
    Duration: r.Duration,
    description: r.specialinstruction,
  };
  DrugData.push(s);
  i += 1;
});

async function populateDrugs(data, doc) {
  doc.moveDown(2);

  const drugTable = {
    headers: [
      {
        label: "S.No",
        property: "No",
        width: 50,
        renderer: null,
        backgroundColor: "#f7ede4",
      },
      {
        label: "Medication",
        property: "Medication",
        width: 150,
        renderer: null,
        backgroundColor: "#f7ede4",
      },
      {
        label: "Strength",
        property: "Strength",
        width: 60,
        renderer: null,
        backgroundColor: "#f7ede4",
      },
      {
        label: "Frequency",
        property: "Frequency",
        width: 60,
        renderer: null,
        backgroundColor: "#f7ede4",
      },
      {
        label: "Duration",
        property: "Duration",
        width: 80,
        renderer: null,
        backgroundColor: "#f7ede4",
      },
      {
        label: "Special Instructions",
        property: "description",
        width: 105,
        renderer: null,
        backgroundColor: "#f7ede4",
      },
    ],
    // complex data

    datas: DrugData,
    options: {
      
      columnSpacing: 5, // {Number} default: 5
    },
  };

  doc.table(drugTable, {
    x: 40,
    prepareHeader: () =>
      doc.font("fonts/TenorSans-Regular.ttf").fontSize(10).fillColor("black"),
    prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {
      doc.font("fonts/Open Sans Regular.ttf").fontSize(9).fillColor("black");
      
    },
  });
}

// Data To Be feeded in Labtest table

// let labtestData = [];
// data.labtest.forEach((r) => {
//   let tempdata = ""

//   tempdata+=r.test
//   tempdata+="\n"
//   tempdata+=r.tests
//   tempdata+='\n'
//   tempdata+='\n'
//   doc.fontSize(4)
//   tempdata+=`To book from Proactive For Her click the link :  ${r.url}`
//   //LinkForLabtest(r)
  
//   let s = {
//     description: tempdata,
//     //text: r.url,
//   };
//   //console.log("d", s)
//   tempdata=""
//   labtestData.push(s);
// });

let labtestData = [];
data.labtest.forEach((r) => {
  // init description text/string
  let description = ""
  description += r.test
  description += "\n"
  description += r.tests
  description += '\n'
  description += '\n'
  description +=`To book from Proactive For Her click the link:  ${r.url}`  
  // push
  labtestData.push({
    description
  });
});

function extractAndCreateLink(value, indexColumn, indexRow, row, rectRow, rectCell){ 
  // get cell dimention
  const {width} = rectCell;
  // slice http url
  const sliceTextAndLinks = String(value).split('http');
  doc
  .fillColor('black')
  // only text
  .text(sliceTextAndLinks[0], {
    width: width,
    continued: true
  })
  .fillColor('blue')
  // link
  // you can change to OPEN HERE or URL
  .text('Link to access', {
    link: `http${sliceTextAndLinks[1]}`,
    // continued: true
  });
  return '';
}

function transformCellOnLink(value, indexColumn, indexRow, row, rectRow, rectCell){ 
  // get cell dimension
  const {x, y, width, height} = rectCell;
  // extract URL
  var urlRegex = /(https?:\/\/[^ ]*)/;
  var url = String(value).match(urlRegex)[1];
  // creact cell link
  doc
  .fillColor('blue')
  .underline( x, y, width, height - 2, { color: '#0000FF' }) // undeline
  .link( x, y, width, height, url)
  return value;
}

async function populateLabTests(data, doc) {
  if (SecondPage==true){
    doc.moveDown(5);
  }
  else{
    doc.moveDown(3)
  }
  const labtestTable = {
    headers: [
      {
        label: "Recommended Lab Tests",
        property: "description",
        width: 505,
        renderer: extractAndCreateLink, // or transformCellOnLink
        backgroundColor: "#f7ede4",
      },
      // {
      //   label: "Booking Links",
      //   property: "text",
      //   width: 205,
      //   renderer: null,
      //   backgroundColor: "#f7ede4",
      // },
    ],

    datas: labtestData,
  };

  doc.table(labtestTable, {
    x: 40,
    prepareHeader: () =>
      doc.font("fonts/TenorSans-Regular.ttf").fontSize(11).fillColor("black"),
    prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {
      doc.font("fonts/Open Sans Regular.ttf").fontSize(9).fillColor("black");
    },
  });
}

async function Suggestions(data, doc) {
  if (SecondPage==true){
    doc.moveDown(5);
  }
  else{
    doc.moveDown(2)
  }
  
  let suggestionData = [];

  data.Suggestions.forEach( (ele) => {
    let s = {
      description: ele.Refer,
    };
    suggestionData.push(s);
  });
  const AnyFurtherSuggestions = {
    headers: [
      {
        label: "Any Further Suggestions",
        property: "description",
        width: 505,
        renderer: null,
        backgroundColor: "#f7ede4",
      },
    ],

    datas: suggestionData,
  };

  doc.table(AnyFurtherSuggestions, {
    x: 40,
    prepareHeader: () =>
      doc.font("fonts/TenorSans-Regular.ttf").fontSize(11).fillColor("black"),
    prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {
      doc.font("fonts/Open Sans Regular.ttf").fontSize(9).fillColor("black");
      
    },
  });
}
async function NextDateAndSignature(data, doc) {
  //Next Consultation Date

  // This is how the next cosult date and curr date format will be written
  
  //let bookingDate = moment(userDetails?.startTime).format("DD-MM-YYYY hh:mm a");

  //addText(doc, `Date of Consultation: ${bookingDate} `, position, y);
  doc.moveDown(1);
  doc.font("fonts/Open Sans Regular.ttf");
  doc.text("Next Consultation Date : 3.5.22", {
    x: 40,
  });
  
  // DIGITAL SIGNATURE

  doc.font("fonts/Open Sans Regular.ttf");
  doc.text("Signature : ", 420);

  doc.moveUp(1.5);
  doc.image("images/signature.jpg", {
    x: 473,
    fit: [170, 13],
    width: 40,
  });
  //Curr Date 
  doc.moveDown(1);
  doc.font("fonts/Open Sans Regular.ttf");
  doc.text("Date : 3.5.22", {
    
  });
}


async function Disclaimer(doc) {
  doc.moveDown(10);
  const Disc = {
    headers: [
      {
        label: "Disclaimer",
        property: "description",
        width: 505,
        renderer: null,
        backgroundColor: "#f7ede4",
      },
    ],

    datas: [
      {
        description:"This prescription is provided by the physician based on the information provided by you on an online consultation basis.The prescriptions provided by the physicians are solely generated based upon the physician's expertise and the information provided by the user. It is the physician who is solely liable for or responsible for the prescription, and Proactive for Her (“PFH”) is in no way responsible for such prescription and hence disclaims all warranties in that regard."
      }
    ],
  };
  
  doc.table(Disc, {
    x: 40,
    y:630,
    prepareHeader: () =>
      doc.font("fonts/TenorSans-Regular.ttf").fontSize(9).fillColor("black"),
    prepareRow: (row, indexColumn, indexRow, rectRow, rectCell) => {
      doc.font("fonts/Open Sans Regular.ttf").fontSize(7).fillColor("black");
      // doc.addBackground(rectRow, '#f7ede4', 0.15)
    },
  });
}





/**
 * Initiate Pdf
 * @param {*} data
 */
const initiatePdf = async (data) => {
  let pageNo = 1
  doc.fontSize(12).fillColor("black");
  addPageFooter(doc);

  addHeader();
  
  addUserDetails(data);
  if (data.DeitRecall.length >= 1) {
    doc.moveDown(2);
    await populateDietRecall(data, doc);
  }
  if (data.notes.length >= 1) {
    doc.moveDown(1);
    await populateNotes(data, doc);
  }

  if (data.LabMedicine.length>=1){
    await populateLabMedicine(data, doc)
  }

  if (data.Diet.length >= 1) {
    await populateDietRecommended(data, doc);
  }

  if (data.drugDetails.length >= 1) {
    await populateDrugs(data, doc);
  }

  console.log("poition of y before labtest", doc.y)
  if (doc.y>=698 && SecondPage==true){
    console.log("goooo")
    pageNo+=1
    doc.addPage()
  }
  else if (doc.y>=640 && len<=150){
    console.log("HELLL0")
    pageNo+=1
    doc.addPage()
    
  }
  else if (doc.y>=625 && len>=220){
    console.log("HELLL")
    pageNo+=1
    doc.addPage()
  }
  
  if (data.labtest.length >= 1) {
    await populateLabTests(data, doc);
  }

  //console.log("poition of y after labtest", doc.y)
  if (doc.y>=698 && SecondPage==true){
    pageNo+=1
    doc.addPage()
  }
  else if (doc.y>=640){
    pageNo+=1
    doc.addPage()
  }

  if (data.Suggestions.length >= 1) {
    await Suggestions(data, doc);
  }

  // DIGITAL SIGNATURE
  //console.log("PAGE NO ", pageNo)
  if (pageNo==2){
    doc.moveDown(5)
    doc.fillColor('black')
  }

  if (doc.y>=698 && SecondPage==true){
    pageNo+=1
    doc.addPage()
  }
  else if (doc.y>=640){
    pageNo+=1
    doc.addPage()
  }
 await NextDateAndSignature(data, doc);
//  console.log("poition of y before disc", doc.y)
//   console.log("page no before dic", pageNo)
  if (doc.y>=698 && SecondPage==true){
    pageNo+=1
    doc.addPage()
  }
  
  else if (doc.y>=635 && pageNo===1){
    pageNo+=1
    doc.addPage()
  }
  await Disclaimer(doc);
  
  doc.end();


};

module.exports = {
  initiatePdf,
};
