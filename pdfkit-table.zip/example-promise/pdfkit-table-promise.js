// comming son. 
// version v0.2.0
/* 

PDFDocumentWithTables

  let pdfkitTableCache
  -------------------- class  
  constructor
  logg
  -------------------- init
  initValidates
  initCalcs
  initColumns
  -------------------- reset
  resetPeerTable
  resetPeerPage
  -------------------- prepare
  prepareTable
  prepareOptions
  prepareCellPadding
  limitCellOnPage
  -------------------- page
  addPageAsync
  pageAddedFire
  -------------------- style
  createRowFill
  createDivider
  -------------------- header
  createHeaderString
  createHeaderObject
  async createHeader
  -------------------- rows and datas
  createRowArray
  createRowObject
  -------------------- calc height
  calcRowHeightString
  calcRowHeightObject
  
  async createTable
  async table
  async tables

*/
const PDFDocument = require("pdfkit");
class PDFDocumentWithTables extends PDFDocument {

  // variables
  pdfkitTableCache = {
    // cache
    title: null,
    subtitle: null,
    headers: {},
    datas: {},
    rows: {},
    options: {},
    // personal
    table: {
      width: 300, // px
      pages: 1,
      lines: 0,
      columns: 0,
      summation: [],
    },
    distanceCorrection: 1.5,
    safelyMarginBottomHeight: 0, // ## remover este item, nao faz mais sentido
    // ## ESTOU CONFUNDINDO NO CODIGO ALTURA SEGURA COM POSICAO SEGURA, arrumar isso nos codigos abaixo
    safelyPageHeight: 0,
    safelyPageY: 0,
  };

  constructor(option) 
  {
    super(option);
    this.opt = option;
  }

  // Init validates
  // ------------------------------------------------------------------

  initValidates() 
  {
    // validate
    if(this.isHeaderString === null || !this.pdfkitTableCache.headers || !this.pdfkitTableCache.headers.length)
    {
      new Error('Please, defined headers. Use hideHeader option to hide header.');
      return;
    }
    // header simple + rows = 0 + datas > 0
    if(this.isHeaderString && !this.pdfkitTableCache.rows.length && this.pdfkitTableCache.datas.length)
    {
      new Error('Combination simple "header" + complex "datas" dont works.');
      return;
    }
    
  }

    // Init calc
  // ------------------------------------------------------------------
  initCalcs() 
  {
    // reset global values
    this.resetPeerTable();
    // reset peer page (add page) #TODO
    this.resetPeerPage();
    // columns
    this.initColumns();
    // fixed initial x position 
    this.initialPositionX = this.pdfkitTableCache.options.x;
    // position by cell
    this.positionX        = this.pdfkitTableCache.options.x;
    // position by row
    this.positionY        = (this.pdfkitTableCache.options.y || this.y) + (this.pdfkitTableCache.distanceCorrection * 2);
    // header
    this.isHeaderString   = this.pdfkitTableCache.headers.length ? (typeof this.pdfkitTableCache.headers[0] === 'string') : null;

    // ------------------------------------------------------------------------
    // remove after
    // ------------------------------------------------------------------------
    this.rowHeight = null;
  }

  initColumns() {
    
    let h = []; // header width
    let p = []; // position
    let w = 0;  // table width

    // (table width) 1o - Max size table
    w = this.page.width - this.page.margins.right - this.pdfkitTableCache.options.x;
    // (table width) 2o - Size defined
    this.pdfkitTableCache.options.width && ( w = String(this.pdfkitTableCache.options.width).replace(/\D+/g,'') >> 0 );

    // (table width) if table is percent of page 
    // ...

    // (size columns) 1o
    this.pdfkitTableCache.headers.forEach( el => {
      el.width && h.push(el.width); // - columnSpacing
    });
    // (size columns) 2o
    if(h.length === 0) {
      h = this.pdfkitTableCache.options.columnsSize;
    } 
    // (size columns) 3o
    if(h.length === 0) {
      h = Array(this.pdfkitTableCache.headers.length).fill((w / this.pdfkitTableCache.headers.length));
    }

    // Set columnPositions
    h.reduce((prev, curr) => {
      p.push(prev >> 0);
      return prev + curr;
    }, this.pdfkitTableCache.options.x);

    // !Set columnSizes
    h.length && (this.columnSizes = h);
    p.length && (this.columnPositions = p);

    // (table width) 3o - Sum last position + lest header width
    // w = p[p.length-1] + h[h.length-1];
    w || (w = h.reduce((prev, curr) => prev + curr, 0));

    console.log('>>>>>', w);

    // !Set tableWidth
    w && (this.pdfkitTableCache.table.width = w);
    
    // Ajust spacing
    // tableWidth = tableWidth - (h.length * columnSpacing); 

    console.log('tableWidth', w);
    console.log('columnSizes', h);
    console.log('columnPositions', p);

  }

  resetPeerTable() 
  {
    this.headerHeight = 0; // cache
    this.headerHeightAndFirstLine = 0; // big cell
    this.headerHeightAndFirstLineAndTitleCalc = 0; // big cell with title
  }

  resetPeerPage() 
  {
    this.pdfkitTableCache.safelyMarginBottomHeight = (this.page.margins.bottom / 1.5);
    this.pdfkitTableCache.safelyPageHeight = this.page.height - (this.page.margins.bottom + this.page.margins.top); // this.page.margins.top +
    this.pdfkitTableCache.safelyPageY = this.page.height - (this.page.margins.bottom);
  }

  // Prepare table data
  // ------------------------------------------------------------------

  prepareTable(table) 
  {
    // parse json 
    typeof table === 'string' && (table = JSON.parse(table));

    // validate
    table                       || (table = {});
    table.headers               || (table.headers = []);
    table.datas                 || (table.datas = []);
    table.rows                  || (table.rows = []);
    table.options               || (table.options = {});

    // global
    this.pdfkitTableCache = { ...this.pdfkitTableCache, ...table };

    return table;
  }

  // Prepare options data
  // ------------------------------------------------------------------

  prepareOptions(options) 
  {
    // validate
    options = options           || {};
    options.hideHeader          || (options.hideHeader = false);
    options.padding             || (options.padding);
    options.columnsSize         || (options.columnsSize = []);
    options.addPage             || (options.addPage = false);
    options.absolutePosition    || (options.absolutePosition = false);
    options.minRowHeight        || (options.minRowHeight = 0);
    options.width               || (options.width = 300);
    // TODO options.hyperlink           || (options.hyperlink = { urlToLink: false, description: null }); // true || false

    // positions
    options.x                   || (options.x = this.page.margins.left || this.x || 0);
    // options.y                   || (options.y = this.page.margins.top);

    // titles
    options.title               || (options.title = '');
    options.subtitle            || (options.subtitle = '');

    // validate padding
    options.padding = this.prepareCellPadding(options.padding);

    // divider lines
    options.divider             || (options.divider             = {});
    options.divider.header      || (options.divider.header      = { disabled: false, width: undefined, opacity: undefined });
    options.divider.horizontal  || (options.divider.horizontal  = { disabled: false, width: undefined, opacity: undefined });
    options.divider.vertical    || (options.divider.vertical    = { disabled: true, width: undefined, opacity: undefined });

    // prepare style
    options.prepareHeader       || (options.prepareHeader = () => this.fillColor('black').font("Helvetica-Bold").fontSize(8).fill());
    options.prepareRow          || (options.prepareRow = (row, indexColumn, indexRow, rectRow, rectCell) => this.fillColor('black').font("Helvetica").fontSize(8).fill());
    // options.prepareCell      || (options.prepareCell = (cell, indexColumn, indexRow, indexCell, rectCell) => this.fillColor('black').font("Helvetica").fontSize(8).fill());

    // validate
    options.preventLongText === undefined && (options.preventLongText = true);

    // global
    this.pdfkitTableCache = { ...this.pdfkitTableCache, options };

    return options;
  }

  // Padding to cells
  // ------------------------------------------------------------------

  /**
   * Entries:
   * 
   * padding: [10, 10, 10, 10]
   * padding: [10, 10]
   * padding: {top: 10, right: 10, bottom: 10, left: 10}
   * padding: 10,
   * 
   * @param {Array | Number} p // padding
   * @returns {
   *   top, right, bottom, left
   * }
   *  
   */
  prepareCellPadding(p)
  {
    // array
    if(Array.isArray(p)){
      switch(p.length){
        case 3: p = [...p, 0]; break;
        case 2: p = [...p, ...p]; break;
        case 1
        : p = Array(4).fill(p[0]); break;
      }
    }
    // number
    else if(typeof p === 'number'){
      p = Array(4).fill(p);
    }
    // object
    else if(typeof p === 'object'){
      const {top, right, bottom, left} = p;
      p = [top, right, bottom, left];
    } 
    // null
    else {
      p = Array(4).fill(0);
    }
    // resolve
    return {
      top:    p[0] >> 0, // int
      right:  p[1] >> 0, 
      bottom: p[2] >> 0, 
      left:   p[3] >> 0,
    };
  };

  // Calc last position + new row height
  // ------------------------------------------------------------------

  limitCellOnPage(y, height) 
  {
    // this.y
    return (y + height + this.pdfkitTableCache.safelyMarginBottomHeight >= this.pdfkitTableCache.safelyPageHeight); // this.page.height
  }

  // Add page async
  // ------------------------------------------------------------------

  addPageAsync()
  {
    const { layout, size, margins } = this.page;
    this.addPage({ layout, size, margins });
    return Promise.resolve();          
  }

  // Add page event
  // ------------------------------------------------------------------

  // event emitter
  pageAddedFire()
  {
    // +1
    this.pdfkitTableCache.table.pages += 1;

    // reset peer page (when change direction)
    this.resetPeerPage();

    // reset
    this.initialPositionY = this.page.margins.top;
    this.positionY = this.page.margins.top;

    // add header
    const { headers, options } = this.pdfkitTableCache;
    this.createHeader({ headers, options });

  };

  // Row fill (background header, cells and rows)
  // ------------------------------------------------------------------

  createRowFill({ x, y, width, height }, fillColor, fillOpacity, callback) 
  {
    this.logg('createRowFill');
    return new Promise((resolve, reject) => 
    {
      try 
      {
        const distance = this.pdfkitTableCache.distanceCorrection; // 1.5 // distance // #TODO padding.top and bottom

        // validate
        fillColor || (fillColor = 'grey');
        fillOpacity || (fillOpacity = 0.1);

        // save current style
        this.save();

        // draw bg
        this
        .fill(fillColor)
        //.stroke(fillColor)
        .fillOpacity(fillOpacity)
        // .rect(x, y, width, height + (distance * 2))
        // .rect(x, y - (distance * 3), width, height + (distance * 2))
        .rect(x, y - (distance * 3), width, height + (distance * 2))
        //.stroke()
        .fill();

        // back to saved style
        this.restore();
        // callback
        typeof callback === 'function' && callback(this);
        // done
        resolve(this);
      } 
      catch (error) 
      {
        this.logg(error);
        reject(error);
      }
    });
  }

  // Divider
  // ------------------------------------------------------------------

  createDivider(type, x, y, strokeWidth, strokeOpacity, strokeDisabled)
  {
    // validate
    type || (type = 'horizontal'); // header | horizontal | vertical 
    const { width, opacity, disabled } = this.pdfkitTableCache.options.divider[type] || {}; 
    // strokeWidth     = strokeWidth    || this.pdfkitTableCache.options.divider[type].width || 0.5;
    // strokeOpacity   = strokeOpacity  || this.pdfkitTableCache.options.divider[type].opacity || 0.5;
    // strokeDisabled  = strokeDisabled || this.pdfkitTableCache.options.divider[type].disabled || false;
    strokeWidth     = strokeWidth    || width    || 0.5;
    strokeOpacity   = strokeOpacity  || opacity  || 0.5;
    strokeDisabled  = strokeDisabled || disabled || false;

    if(strokeDisabled)
    {
      return;
    }
    
    // variables
    const distance = this.pdfkitTableCache.distanceCorrection; // 1.5 // distance // #TODO padding.top and bottom
    const s = (strokeWidth / 2) - distance; // space line and letter
    const m = this.pdfkitTableCache.options.x || this.page.margins.left || 0; // margin
    
    // this.logg(distance, s, m, x, y, strokeWidth, strokeOpacity, this.pdfkitTableCache.table.width);

    // save style
    this.save();

    // draw
    this
    .moveTo(x, y + s)
    .lineTo(this.pdfkitTableCache.table.width + this.pdfkitTableCache.options.x, y + s)
    .lineWidth(strokeWidth)
    .opacity(strokeOpacity)
    .stroke()
    // Reset opacity after drawing the line
    .opacity(1);

    // reset style
    this.restore();

    // add
    this.positionY += strokeWidth + (distance * 2);

    // return this;
  }

  // Header array (simple)
  // ------------------------------------------------------------------

  createHeaderString({ headers, options }) 
  {
    this.logg('createHeaderString');
    return new Promise( async (resolve, reject) => 
    {
      try {
       
        // variables
        const { top, right, bottom, left } = this.pdfkitTableCache.options.padding;
        let colIndex; // index
        let colLen = headers.length || 0; // array columns
        let text;

        // x reset
        // this.positionX = this.initialPositionX;

        // apply style
        this.save();
        this.pdfkitTableCache.options.prepareHeader();

        // calc row height
        this.headerHeight || (this.headerHeight = await this.calcRowHeightString(headers, { isHeader: true }));

        // calc first table line when init table
        if(this.headerHeightAndFirstLine === 0)
        {
          if(this.pdfkitTableCache.datas.length > 0)
          {
            this.headerHeightAndFirstLine = await this.calcRowHeightObject(this.pdfkitTableCache.datas[0], { isHeader: true });
            this.logg(this.headerHeightAndFirstLine, 'datas');
          }
          else if(this.pdfkitTableCache.rows.length > 0)
          {
            this.headerHeightAndFirstLine = await this.calcRowHeightString(this.pdfkitTableCache.rows[0], { isHeader: true });
            this.logg(this.headerHeightAndFirstLine, 'rows');
          }
        }

        // calc if header + first line fit on last space page
        this.headerHeightAndFirstLine += this.pdfkitTableCache.title    ? 13.1 : 0; 
        this.headerHeightAndFirstLine += this.pdfkitTableCache.subtitle ? 11.1 : 0; 
        this.headerHeightAndFirstLineAndTitleCalc = this.positionY + this.headerHeightAndFirstLine + this.headerHeight + this.pdfkitTableCache.safelyMarginBottomHeight;
        // console.log('Calc height cell + header height', this.headerHeightAndFirstLineAndTitleCalc, this.page.height, this.pdfkitTableCache.safelyPageHeight);

        console.log('headerHeightAndFirstLine', this.headerHeightAndFirstLine, this.headerHeightAndFirstLineAndTitleCalc)

        // content is big text (crazy!)
        if(this.headerHeightAndFirstLine > this.page.height) 
        {
          const err = 'CRAZY! This a big text on cell';
          console.log(err);
          this.logg(err);
          // this.fontSize(8);
          // new Error(err);
          // return;
        } 
        else if(this.headerHeightAndFirstLineAndTitleCalc > this.page.height) 
        {
          this.logg('addPage');
          console.log('addPage');
          await this.addPageAsync();
          resolve();
          return;
        } 

        // fill header
        // this.createRowFill({ x: this.initialPositionX, y: this.positionY, width: this.pdfkitTableCache.table.width, height: this.headerHeight });
        this.createRowFill({ x: this.columnPositions[0], y: this.positionY, width: this.pdfkitTableCache.table.width, height: this.headerHeight });

        // columns
        for(colIndex = 0; colIndex < colLen; colIndex++) 
        {
          // validade
          text = headers[colIndex];
          this.logg(text, colIndex);
          this.text(text, this.columnPositions[colIndex] + left, this.positionY + top, 
          {
            width: this.columnSizes[colIndex] - (left + right),
            align: 'left',
          });

          // x add
          // this.positionX += this.columnSizes[colIndex];
        }

        // /!\ dont changer order
        // y add
        this.positionY += this.headerHeight;
        // divider
        // this.createDivider('horizontal', this.initialPositionX, this.positionY, 1, 1);
        this.createDivider('horizontal', this.columnPositions[0], this.positionY, 1, 1);
        // style restore
        this.restore();
        this.pdfkitTableCache.options.prepareRow();
        // to global
        this.pdfkitTableCache.table.columns = colLen;

        // done
        resolve();        
      } 
      catch (error)
      {
        // error
        reject(error);
      }
    });
  }

  // Header object (complex)
  // ------------------------------------------------------------------

  createHeaderObject(data) 
  {
    this.logg('createHeaderObject');
    return new Promise( async (resolve, reject) => 
    {
      const { headers } = data;
      
      headers.forEach((col, heIndex) => {
        this.logg(col);
      });

      // to global
      // this.pdfkitTableCache.table.columns = colLen;

      resolve();
    });
  }

  // Init header key:@header
  // ------------------------------------------------------------------

  async createHeader({ headers, options }) 
  {
    this.logg('createHeader');

    if(this.isHeaderString)
    {
      await this.createHeaderString({ headers, options });
    } 
    else 
    {
      await this.createHeaderObject({ headers, options });
    }

    return Promise.resolve();
  }

  // Rows - tables.rows key:@rows
  // ------------------------------------------------------------------

  createRowArray(data) 
  {
    this.logg('createRowArray');
    return new Promise( async (resolve, reject) => 
    {
      // local
      const { rows, options } = data;

      // has content
      if(!rows || !rows.length)
      {
        resolve();
        return;
      }

      // is array whith object
      if(!Array.isArray(rows[0]) || typeof rows[0][0] !== 'string')
      {
        reject();
        throw new Error('ROWS need be a Array[] with String"". See documentation.');
        return;
      }

      // variables
      const { top, right, bottom, left } = this.pdfkitTableCache.options.padding;
      let rowIndex, colIndex; // index
      let rowLen = rows.length || 0; // array lines
      let colLen = rows[0].length || 0; // array columns
      let elm; // element line
      let text;

      // loop lines
      for(rowIndex = 0; rowIndex < rowLen; rowIndex++) 
      {
        // style
        this.pdfkitTableCache.options.prepareRow();

        // row calc
        const [rowHeight, longText, haveLongText] = await this.calcRowHeightString(rows[rowIndex], { isHeader: false, preventLongText: true });
        this.rowHeight = rowHeight;

        if(haveLongText) this.logg(`CRAZY! This a big text on cell`);

        // Switch to next page if we cannot go any further because the space is over.
        // For safety, consider 3 rows margin instead of just one
        // this.y + this.rowHeight + this.pdfkitTableCache.safelyMarginBottomHeight >= this.pdfkitTableCache.safelyPageHeight
        if(this.limitCellOnPage(this.positionY, this.rowHeight) || haveLongText)
        {
          // const { layout, size, margins } = this.page;
          // await this.addPage({ layout, size, margins });
          await this.addPageAsync();
        }

        console.log(this.y, this.pdfkitTableCache.safelyMarginBottomHeight, this.pdfkitTableCache.safelyPageHeight, this.page.height);
        console.log(rowIndex, 'Y position to writer ', this.positionY + this.rowHeight + this.pdfkitTableCache.safelyMarginBottomHeight, 
        this.y + this.rowHeight + this.pdfkitTableCache.safelyMarginBottomHeight);

        // x reset 1o time
        // this.positionX = this.initialPositionX;
        // element
        elm = rows[rowIndex];

        // loop columns
        for(colIndex = 0; colIndex < colLen; colIndex++) 
        {

          // Prevent break page with long text
          // ----------------------------------------------------

          // validade
          text = elm[colIndex];
          
          // big text
          if(haveLongText)
          {
            // if have value to work
            if(longText[colIndex])
            {
              const { fitValue, fitHeight, percent } = longText[colIndex];
              // fit text
              text = fitValue;
              // row calc
              this.rowHeight = fitHeight; // this.rowHeight / percent;
              // restValue
              // console.log(longText[colIndex]);              
              
              // if(this.rowHeight > this.pdfkitTableCache.safelyPageHeight - this.headerHeight) {
              //   console.log('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAa')
              //   this.rowHeight -= this.headerHeight;
              //   console.log('BBBBBB', this.rowHeight, this.pdfkitTableCache.safelyPageHeight, this.page.height, this.headerHeight)
              // }
            }
            
          }
          // ----------------------------------------------------

          // fill cell
          this.createRowFill({ x: this.columnPositions[colIndex], y: this.positionY, width: this.columnSizes[colIndex], height: this.rowHeight }, colIndex % 2 ? 'grey' : 'green', 0.2);
          // style
          this.pdfkitTableCache.options.prepareRow(elm, colIndex, rowIndex, {}, {});          
          // write
          this.text(text, this.columnPositions[colIndex] + left, this.positionY + top,
          {
            // width: this.cellWidth - (left + right),
            width: this.columnSizes[colIndex] - (left + right),
            align: 'left',
          });

          // x add
          // this.positionX += this.cellWidth;
          // console.log(rowIndex, colIndex, this.columnSizes[colIndex], this.columnPositions[colIndex]);
        }

        // /!\ dont changer order
        // y add
        this.positionY += this.rowHeight;
        // x reset 2o time
        // this.positionX = this.initialPositionX;
        // divider
        // this.createDivider('horizontal', this.initialPositionX, this.positionY);
        this.createDivider('horizontal', this.columnPositions[0], this.positionY);
        
        if(haveLongText)
        {
          // await this.addPageAsync();
        }
      }

      // x reset
      // this.positionX = this.initialPositionX;
      // to global
      this.pdfkitTableCache.table.lines = rowLen;

      resolve(this);
    });
  }

  // Data - tables.datas key:@datas
  // ------------------------------------------------------------------

  createRowObject(data) 
  {
    this.logg('createRowObject');
    return new Promise((resolve, reject) => 
    {
      // variables
      const { datas, headers } = data;

      // has content
      if(!datas || !datas.length)
      {
        resolve();
        return;
      }

      // is array whith object
      if(Array.isArray(datas[0]) || typeof datas[0] !== 'object')
      {
        reject();
        throw new Error('Datas need be a Array[] with Objects{}. See documentation.');
        return;
      }

      // loop
      datas.forEach((row, elIndex) => {
        this.logg(row);
        headers.forEach((col, heIndex) => {
          this.logg(col);
        });
      });

      // to global
      // this.pdfkitTableCache.table.lines = rowLen;

      resolve();
    });
  }



  // Calc row height (from array)
  // ------------------------------------------------------------------

  calcRowHeightString(row, { align, isHeader, preventLongText })
  {
    return new Promise((resolve, reject) => 
    {
      // criar um padding para header  ???/
      // cellp = this.prepareCellPadding(this.pdfkitTableCache.headers[i].padding || this.pdfkitTableCache.options.padding || 0);

      // validate
      isHeader === undefined && (isHeader = false);
      align || (align = 'left');

      // variables
      let text = '';
      let height = isHeader ? 0 : (this.pdfkitTableCache.minRowHeight || 0);
      let heightCompute = 0;
      let len = row.length || 0;
      let i = 0;
      let haveLongText = false;
      let veryLongText = [];

      // validate
      const { left, top, right, bottom } = this.pdfkitTableCache.options.padding;

      // style
      if(isHeader)
      {
        this.pdfkitTableCache.options.prepareHeader();
      }
      else
      {
        this.pdfkitTableCache.options.prepareRow();
      }

      // loop
      for(i = 0; i < len; i++) 
      {
        // value
        text = row[i];
        text = String(text).replace('bold:','').replace('size','').replace(/^:/g,'');

        // calc height size of string
        heightCompute = this.heightOfString(text, 
        {
          lineGap: 0,
          width: this.columnSizes[i] - (left + right),
          align,
        });
        
        // stay max height
        height = Math.max(height, heightCompute);

        // register long text
        if(preventLongText)
        {
          // console.log('preventLongText', heightCompute, this.pdfkitTableCache.safelyPageHeight);

          // if row height is bigger 
          if(heightCompute > this.pdfkitTableCache.safelyPageHeight) 
          {
            haveLongText = true;

            // console.log('ENTROU NO MODO RECALCULA LINE', heightCompute, this.pdfkitTableCache.safelyPageHeight);

            // variables
            let safeHeight  = this.pdfkitTableCache.safelyPageHeight - this.headerHeight - (this.pdfkitTableCache.distanceCorrection * 4);
            let percent     = heightCompute / (safeHeight) + 0.01; // 0.3 safe
            let fitHeight   = safeHeight; // - this.page.margins.top; //heightCompute / percent;
            let lenTextTest = text.length / percent - 70; // 50
            let fitValue;

            // console.log('fitHeight', fitHeight, percent)

            // pt-br: veja bem, dependendo do tamanho da font esse recurso ajuda o 
            // text a não pular de página ou evitar o text ficar muito encolhido em relação 
            // a página quando a fonte for muito pequena
            // 
            // fontSize(17)   fontSize(7)    fontSize(x)
            // very long      very short     perfect correction
            // ___________    ___________    ___________
            // | -- | -- |    | -- | -- |    | -- | -- |
            // | -- |    |    | -- |    |    | -- |    |
            // | -- |    |    |    |    |    | -- |    |
            // | -- |    |    |    |    |    | -- |    |
            // | -- |    |    |    |    |    |    |    |
            //   -- 
            // correction/recalc text to new row height
            let maxLoop = 14;
            for(let ilen = 0; ilen < maxLoop; ilen++) {

              lenTextTest = lenTextTest + (10 * ilen);
              lenTextTest = (lenTextTest > text.length ? text.length: lenTextTest) -7;
              const fitValueTest = String(text).substring(0, lenTextTest);
              const heightComputeFit = this.heightOfString(fitValueTest, 
              {
                lineGap: 0,
                width: this.columnSizes[i] - (left + right),
                align,
              });

              if(heightComputeFit < fitHeight) {
                fitValue = fitValueTest;
              } else {
                ilen = maxLoop;
              }
            }
      
            // console.log(heightComputeFit, fitHeight, safeHeight, this.page.height, heightCompute, percent);
                  
            // push prevent
            veryLongText.push({
              index: i,
              key: null,
              value: text,
              fitValue: `${fitValue} +${text.length - fitValue.length - 7}...`,
              restValue: String(text).substring(text.length - fitValue.length - 7),
              fitHeight, // or height (try more columns)
            });      
          }
          // null if normal row size
          else
          {
            veryLongText.push(null);
          }
        }
      }
      
      // minimum row height 
      // height = Math.max(height, this.pdfkitTableCache.minRowHeight || 0);
      height = height + this.pdfkitTableCache.distanceCorrection + top + bottom;
      
      // return array
      if(preventLongText) 
      {
        resolve([
          height,
          veryLongText,
          haveLongText
        ]);  
      } 
      else 
      {
        resolve(height);
      }
      
    });
  };

  // Calc row height (from object)
  // ------------------------------------------------------------------

  calcRowHeightObject(row)
  {
    let result = 0;
    let cellp;

    // if row is object, content with property and options
    if(!Array.isArray(row) && typeof row === 'object' && !row.hasOwnProperty('property')){
      const cells = []; 
      // get all properties names on header
      this.pdfkitTableCache.headers.forEach(({property}) => cells.push(row[property]) );
      // define row with properties header
      row = cells;
    }

    row.forEach((cell,i) => {
      let text = cell;
      // object
      // read cell and get label of object
      if( typeof cell === 'object' ){
        // define label
        text = String(cell.label);
        // apply font size on calc about height row 
        //cell.hasOwnProperty('options') && prepareRowOptions(cell);
      }

      text = String(text).replace('bold:','').replace('size','');
      // cell padding
      cellp = this.prepareCellPadding(this.pdfkitTableCache.headers[i].padding || this.pdfkitTableCache.options.padding || 0);

      // calc height size of string
      const cellHeight = this.heightOfString(text, 
      {
        // width: columnSizes[i] - (cellp.left + cellp.right),
        width: this.cellWidth - (cellp.left + cellp.right),
        align: 'left',
      });
      result = Math.max(result, cellHeight);
    });

    return result; // + columnSpacing;
  }

  // Init loop key:@data
  // ------------------------------------------------------------------

  async createTable(data) 
  {
    this.logg('createTable');
    return new Promise(async (resolve) => 
    {
      // variables
      const { table } = data;
        let { headers, datas, rows } = table;

      // lopps
      await this.createRowObject({ headers, datas });
      await this.createRowArray({ headers, rows });

      resolve(this);
    });
  }


  // Resume
  // ------------------------------------------------------------------

  tableResume() {
    return {
      ...this.pdfkitTableCache.table,
      y: this.positionY,
      x: this.positionX,  
    }
  }

  // Table - THE MAGIC
  // ------------------------------------------------------------------

  async table(table, options, callback) 
  {
    // prepare
    table   = this.prepareTable(table);
    options = this.prepareOptions(options);
    options = { ...options, ...table.options }; // merge options

    this.initCalcs();
    this.initValidates();

    // on fire
    this.on('pageAdded', this.pageAddedFire);

    // init
    this.logg('table');
    try 
    {
      await this.createHeader({ headers: table.headers, options });
      await this.createTable({ table, options });
      // break
      this.moveDown();
    } 
    catch (error) 
    {
      console.error(error);
      throw new Error(error);
    }

    // off fire
    this.off('pageAdded', this.pageAddedFire);

    // this.logg(resolve);
    typeof callback === 'function' && callback(this.tableResume());
    return Promise.resolve(this.tableResume());
  }

  // Join tables
  // ------------------------------------------------------------------

  async tables(tables, callback) {
    return new Promise( async (resolve, reject) => 
    {
      try 
      {
        if(Array.isArray(tables)) 
        {
          // many tables
          for(let i = 0; i < tables.length; i++) 
          {
            await this.table(tables[i], tables[i].options || {});
          }
        }
        else if(typeof tables === 'object') 
        {
          // else is tables is a unique table object
          await this.table(tables, tables.options || {});
        }
      
        // callback
        typeof callback === 'function' && callback(this.tableResume());
        // done!
        resolve(this.tableResume());
      } 
      catch (error) 
      {
        // ops!
        reject(error);
      }
    });
  }

  logg(...args) 
  {
    // console.log(args);
  }

}

module.exports = PDFDocumentWithTables;