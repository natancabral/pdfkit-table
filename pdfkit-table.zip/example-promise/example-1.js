/**
 * You need to install on terminal (node.js):
 * -----------------------------------------------------
 * $ npm install pdfkit-table
 * -----------------------------------------------------
 * Run this file:
 * -----------------------------------------------------
 * $ node index-example.js
 * -----------------------------------------------------
 * 
 */

const fs = require("fs");
// const PDFDocument = require("../index");
// const PDFDocument = require("./index-back-padding-version");
const PDFDocument = require("./pdfkit-table-promise.js");
const doc = new PDFDocument({
  margin: 30, 
  // margin: 70, // error
});
 
// to save on server
doc.pipe(fs.createWriteStream("./example-1.pdf"));

// -----------------------------------------------------------------------------------------------------
// Simple Table with Array
// -----------------------------------------------------------------------------------------------------
const table = {
  headers: ["Country Country Country", "Conversion rate", "Trend"],
  rows: [
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    
    ["Here her break", "33%", "+4.44%"],

    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France 3", "67%", "-0.98%"],
    ["England 3", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England 4", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France France France France", "67%", "-0.98%"],
    ["England 5", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["Switzerland", "12%", "+1.12%"],
    ["France", "67%", "-0.98%"],
    ["England", "33%", "+4.44%"],
    ["England of England of England", "33%", "+4.44%"],
    ["England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of Eng", "33%", "+4.44%"],
    ["England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of England of EnglandEngland of England of England England of England of England England of England of England England of Eng", "33%", "+4.44%"],
    // ["Sim Sim Sim", "00%", "+1.12%"],
    // ["France", "67%", "-0.98%"],
    // ["England", "33%", "+4.44%"],
    // ["England of England of England", "33%", "+4.44%"],
    // ["Switzerland", "12%", "+1.12%"],
    // ["France", "67%", "-0.98%"],
    // ["England", "33%", "+4.44%"],
    // ["England of England of England", "33%", "+4.44%"],
    // ["Switzerland", "12%", "+1.12%"],
    // ["France", "67%", "-0.98%"],
    // ["England", "33%", "+4.44%"],
    // ["England of England of England", "33%", "+4.44%"],
    // ["Switzerland", "12%", "+1.12%"],
    // ["France", "67%", "-0.98%"],
    // ["England", "33%", "+4.44%"],
    // ["England of England of England", "33%", "+4.44%"],
  ],
};
const options = {
  width: 300,
  x: 150,
  // y: 150,
  padding: {
    top: 1, bottom: 1, left: 5, right: 5, 
  },
  // prepareHeader: () => { doc.fontSize(9) },
  // prepareRow: () => { doc.fontSize(7) }
};
doc.fontSize(9).font('Helvetica');
doc.table(table, options).then( (data) => {
  doc.end();
  console.log(data);
});


// A4 595.28 x 841.89 (portrait) (about width sizes)
 
 // if your run express.js server:
 // HTTP response only to show pdf
 // doc.pipe(res);
 
 // done
 
