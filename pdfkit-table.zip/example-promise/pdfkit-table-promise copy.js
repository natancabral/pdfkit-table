// comming son. 
// version v0.2.0
/* 

PDFDocumentWithTables

  let pdfkitTableCache
  -------------------- class  
  constructor
  logg
  -------------------- init
  initValidates
  initCalcs
  -------------------- reset
  resetPeerTable
  resetPeerPage
  -------------------- prepare
  prepareTable
  prepareOptions
  prepareHeader
  prepareCellPadding
  limitCellOnPage
  -------------------- page
  addPageAsync
  pageAddedFire
  -------------------- style
  createRowFill
  createDivider
  -------------------- header
  createHeaderString
  createHeaderObject
  async createHeader
  -------------------- rows and datas
  createRowArray
  createRowObject
  -------------------- calc height
  calcRowHeightString
  calcRowHeightObject
  
  async createTable
  async table
  async tables

*/
const PDFDocument = require("pdfkit");
class PDFDocumentWithTables extends PDFDocument {

  // variables
  pdfkitTableCache = {
    // cache
    headers: {},
    datas: {},
    rows: {},
    options: {},
    // personal
    table: {
      width: 300, // px
      pages: 1,
      lines: 0,
      columns: 0,
      summation: [],
    },
    distanceCorrection: 1.5,
    safelyMarginBottom: 0, 
    safelyPageHeight: 0,
  };

  constructor(option) 
  {
    super(option);
    this.opt = option;
  }

  // Init validates
  // ------------------------------------------------------------------

  initValidates() 
  {
    // validate
    if(this.headerIsString === null || !this.pdfkitTableCache.headers || !this.pdfkitTableCache.headers.length)
    {
      new Error('Please, defined headers. Use hideHeader option to hide header.');
      return;
    }
    // header simple + rows = 0 + datas > 0
    if(this.headerIsString && !this.pdfkitTableCache.rows.length && this.pdfkitTableCache.datas.length)
    {
      new Error('Combination simple "header" + complex "datas" dont works.');
      return;
    }
  }

    // Init calc
  // ------------------------------------------------------------------
  initCalcs() 
  {
    // reset global values
    this.resetPeerTable();
    // reset peer page (add page) #TODO
    this.resetPeerPage();
    // fixed initial x position 
    this.initialPositionX = this.pdfkitTableCache.options.x  || this.page.margins.left;
    // position by cell
    this.positionX        = this.pdfkitTableCache.options.x  || this.page.margins.left;
    // position by row
    this.positionY        = (this.pdfkitTableCache.options.y || this.y) + (this.pdfkitTableCache.distanceCorrection * 2);
    // ------------------------------------------------------------------------
    // remove after
    // ------------------------------------------------------------------------
    this.rowHeight = null;
    this.cellWidth = 100; // array
    this.pdfkitTableCache.table.width || (this.pdfkitTableCache.table.width = options.width); // remove after    
  }

  resetPeerTable() 
  {
    this.headerHeight = 0; // cache
    this.headerHeightAndFirstLine = 0; // big cell
    this.headerHeightAndFirstLineAndTitleCalc = 0; // big cell with title
  }

  resetPeerPage() 
  {
    this.pdfkitTableCache.safelyMarginBottom = (this.page.margins.bottom / 1.5);
    this.pdfkitTableCache.safelyPageHeight = this.page.height - (this.page.margins.bottom); // this.page.margins.top +
  }

  // Prepare table data
  // ------------------------------------------------------------------

  prepareTable(table) 
  {
    // parse json 
    typeof table === 'string' && (table = JSON.parse(table));

    // validate
    table                       || (table = {});
    table.headers               || (table.headers = []);
    table.datas                 || (table.datas = []);
    table.rows                  || (table.rows = []);
    table.options               || (table.options = {});

    // // prepare
    table.header = this.prepareHeader(table.headers);

    // global
    this.pdfkitTableCache = { ...this.pdfkitTableCache, ...table };

    return table;
  }

  // Prepare options data
  // ------------------------------------------------------------------

  prepareOptions(options) 
  {
    // validate
    options = options           || {};
    options.hideHeader          || (options.hideHeader = false);
    options.padding             || (options.padding);
    options.columnsSize         || (options.columnsSize = []);
    options.addPage             || (options.addPage = false);
    options.absolutePosition    || (options.absolutePosition = false);
    options.minRowHeight        || (options.minRowHeight = 0);
    options.width               || (options.width = 300);

    // titles
    options.title               || (options.title = '');
    options.subtitle            || (options.subtitle = '');

    // validate padding
    options.padding             = this.prepareCellPadding(options.padding);

    // divider lines
    options.divider             || (options.divider             = {});
    options.divider.header      || (options.divider.header      = { disabled: false, width: undefined, opacity: undefined });
    options.divider.horizontal  || (options.divider.horizontal  = { disabled: false, width: undefined, opacity: undefined });
    options.divider.vertical    || (options.divider.vertical    = { disabled: true, width: undefined, opacity: undefined });

    // prepare style
    options.prepareHeader       || (options.prepareHeader = () => this.fillColor('black').font("Helvetica-Bold").fill());
    options.prepareRow          || (options.prepareRow = (row, indexColumn, indexRow, rectRow, rectCell) => this.fillColor('black').font("Helvetica").fill());
    // options.prepareCell      || (options.prepareCell = (cell, indexColumn, indexRow, indexCell, rectCell) => this.fillColor('black').font("Helvetica").fontSize(8).fill());

    // global
    this.pdfkitTableCache = { ...this.pdfkitTableCache, options };

    return options;
  }

  // Prepare header array
  // ------------------------------------------------------------------

  prepareHeader(headers) 
  {
    // header is simple or complex
    this.headerIsString = headers.length ? (typeof headers[0] === 'string') : null;

    // validate objects value
    if(!this.headerIsString)
    {
      console.log('Header os objects');
      headers = headers.map(function(el) 
      {
        if(el.hasOwnProperty('padding')) {
          el.padding = this.prepareCellPadding(el.padding);
        } else {
          el.padding = false;
        }
        return el;
      })
    }

    return headers;
  }

  // Padding to cells
  // ------------------------------------------------------------------

  /**
   * Entries:
   * 
   * padding: [10, 10, 10, 10]
   * padding: [10, 10]
   * padding: {top: 10, right: 10, bottom: 10, left: 10}
   * padding: 10,
   * 
   * @param {Array | Number} p // padding
   * @returns {
   *   top, right, bottom, left
   * }
   *  
   */
  prepareCellPadding(p)
  {
    // array
    if(Array.isArray(p)){
      switch(p.length){
        case 3: p = [...p, 0]; break;
        case 2: p = [...p, ...p]; break;
        case 1
        : p = Array(4).fill(p[0]); break;
      }
    }
    // number
    else if(typeof p === 'number'){
      p = Array(4).fill(p);
    }
    // object
    else if(typeof p === 'object'){
      const {top, right, bottom, left} = p;
      p = [top, right, bottom, left];
    } 
    // null
    else {
      p = Array(4).fill(0);
    }
    // resolve
    return {
      top:    p[0] >> 0, // int
      right:  p[1] >> 0, 
      bottom: p[2] >> 0, 
      left:   p[3] >> 0,
    };
  };

  // Calc last position + new row height
  // ------------------------------------------------------------------

  limitCellOnPage(height) 
  {
    return (this.y + height + this.pdfkitTableCache.safelyMarginBottom >= this.pdfkitTableCache.safelyPageHeight);
  }

  // Add page async
  // ------------------------------------------------------------------

  addPageAsync()
  {
    const { layout, size, margins } = this.page;
    this.addPage({ layout, size, margins });
    return Promise.resolve();          
  }

  // Add page event
  // ------------------------------------------------------------------

  // event emitter
  pageAddedFire()
  {
    // +1
    this.pdfkitTableCache.table.pages += 1;

    // reset peer page (when change direction)
    this.resetPeerPage();

    // reset
    this.initialPositionY = this.page.margins.top;
    this.positionY = this.page.margins.top;

    // add header
    const { headers, options } = this.pdfkitTableCache;
    this.createHeader({ headers, options });

  };

  // Row fill (background header, cells and rows)
  // ------------------------------------------------------------------

  createRowFill({ x, y, width, height }, fillColor, fillOpacity, callback) 
  {
    this.logg('createRowFill');
    return new Promise((resolve, reject) => 
    {
      try 
      {
        const distance = this.pdfkitTableCache.distanceCorrection; // 1.5 // distance // #TODO padding.top and bottom

        // validate
        fillColor || (fillColor = 'grey');
        fillOpacity || (fillOpacity = 0.1);

        // save current style
        this.save();

        // draw bg
        this
        .fill(fillColor)
        //.stroke(fillColor)
        .fillOpacity(fillOpacity)
        // .rect(x, y, width, height + (distance * 2))
        // .rect(x, y - (distance * 3), width, height + (distance * 2))
        .rect(x, y - (distance * 3), width, height + (distance * 2))
        //.stroke()
        .fill();

        // back to saved style
        this.restore();
        // callback
        typeof callback === 'function' && callback(this);
        // done
        resolve(this);
      } 
      catch (error) 
      {
        this.logg(error);
        reject(error);
      }
    });
  }

  // Divider
  // ------------------------------------------------------------------

  createDivider(type, x, y, strokeWidth, strokeOpacity, strokeDisabled)
  {
    // validate
    type || (type = 'horizontal'); // header | horizontal | vertical 
    const { width, opacity, disabled } = this.pdfkitTableCache.options.divider[type] || {}; 
    // strokeWidth     = strokeWidth    || this.pdfkitTableCache.options.divider[type].width || 0.5;
    // strokeOpacity   = strokeOpacity  || this.pdfkitTableCache.options.divider[type].opacity || 0.5;
    // strokeDisabled  = strokeDisabled || this.pdfkitTableCache.options.divider[type].disabled || false;
    strokeWidth     = strokeWidth    || width    || 0.5;
    strokeOpacity   = strokeOpacity  || opacity  || 0.5;
    strokeDisabled  = strokeDisabled || disabled || false;

    if(strokeDisabled)
    {
      return;
    }
    
    // variables
    const distance = this.pdfkitTableCache.distanceCorrection; // 1.5 // distance // #TODO padding.top and bottom
    const s = (strokeWidth / 2) - distance; // space line and letter
    const m = this.pdfkitTableCache.options.x || this.page.margins.left || 30; // margin
    
    this.logg(distance, s, m, x, y, strokeWidth, strokeOpacity, this.pdfkitTableCache.table.width);

    // save style
    this.save();

    // draw
    this
    .moveTo(x, y + s)
    .lineTo(x + this.pdfkitTableCache.table.width, y + s)
    .lineWidth(strokeWidth)
    .opacity(strokeOpacity)
    .stroke()
    // Reset opacity after drawing the line
    .opacity(1);

    // reset style
    this.restore();

    // add
    this.positionY += strokeWidth + (distance * 2);

    // return this;
  }

  // Header array (simple)
  // ------------------------------------------------------------------

  createHeaderString({ headers, options }) 
  {
    this.logg('createHeaderString');
    return new Promise( async (resolve, reject) => 
    {
      try {
       
        // variables
        const { top, right, bottom, left } = this.pdfkitTableCache.options.padding;
        let colIndex; // index
        let colLen = headers.length || 0; // array columns
        let text;

        // x reset
        this.positionX = this.initialPositionX;

        // apply style
        this.save();
        this.pdfkitTableCache.options.prepareHeader();

        // calc row height
        if(!this.headerHeight)
        {
          if(this.headerIsString) 
          {
            this.headerHeight = await this.calcRowHeightString(headers, { isHeader: true });
          }
          else
          {
            this.headerHeight = await this.calcRowHeightObject(headers, { isHeader: true });
          }
        }

        console.log(this.headerHeight);
        return

        // calc first table line when init table
        if(this.headerHeightAndFirstLine === 0)
        {
          if(this.pdfkitTableCache.datas.length > 0)
          {
            this.headerHeightAndFirstLine = await this.calcRowHeightObject(this.pdfkitTableCache.datas[0], { isHeader: true });
            this.logg(this.headerHeightAndFirstLine, 'datas');
          }
          else if(this.pdfkitTableCache.rows.length > 0)
          {
            this.headerHeightAndFirstLine = await this.calcRowHeightString(this.pdfkitTableCache.rows[0], { isHeader: true });
            this.logg(this.headerHeightAndFirstLine, 'rows');
          }
        }

        // calc if header + first line fit on last space page
        this.headerHeightAndFirstLine += this.pdfkitTableCache.table.title    ? 13.1 : 0; 
        this.headerHeightAndFirstLine += this.pdfkitTableCache.table.subtitle ? 11.1 : 0; 
        this.headerHeightAndFirstLineAndTitleCalc = this.positionY + this.headerHeightAndFirstLine + this.headerHeight + this.pdfkitTableCache.safelyMarginBottom;
        // console.log('Calc height cell + header height', this.headerHeightAndFirstLineAndTitleCalc, this.page.height, this.pdfkitTableCache.safelyPageHeight);
        
        // content is big text (crazy!)
        if(this.headerHeightAndFirstLine > this.pdfkitTableCache.safelyPageHeight) 
        {
          const err = 'CRAZY! This a big text on cell';
          console.log(err);
          this.logg(err);
          this.fontSize(8);
          // new Error(err);
          // return;
        } 
        else if(this.headerHeightAndFirstLineAndTitleCalc > this.pdfkitTableCache.safelyPageHeight) 
        {
          this.logg('addPage');
          await this.addPageAsync();
          resolve();
          return;
        } 

        // fill header
        this.createRowFill({ x: this.initialPositionX, y: this.positionY, width: this.pdfkitTableCache.table.width, height: this.headerHeight });

        // columns
        for(colIndex = 0; colIndex < colLen; colIndex++) 
        {
          // validade
          text = headers[colIndex];
          this.logg(text, colIndex);
          this.text(text, this.positionX + left, this.positionY + top, 
          {
            width: this.cellWidth - (left + right),
            align: 'left',
          });

          // x add
          this.positionX += this.cellWidth;
        }

        // /!\ dont changer order
        // y add
        this.positionY += this.headerHeight;
        // divider
        this.createDivider('horizontal', this.initialPositionX, this.positionY, 1, 1);
        // style restore
        this.restore();
        // to global (temporary)
        this.pdfkitTableCache.table.columns = colLen;

        // done
        resolve(this);        
      } 
      catch (error)
      {
        // error
        reject(error);
      }
    });
  }

  // Header object (complex)
  // ------------------------------------------------------------------

  createHeaderObject(data) 
  {
    this.logg('createHeaderObject');
    return new Promise( async (resolve, reject) => 
    {
      const { headers } = data;
      
      // datas.forEach((row, elIndex) => {
      //   this.logg(row);
      //   headers.forEach((col, heIndex) => {
      //     this.logg(col);
      //   });
      // });

      // to global
      // this.pdfkitTableCache.table.columns = colLen;

      resolve();
    });
  }

  // Init header
  // ------------------------------------------------------------------

  async createHeader({ headers, options }) 
  {
    this.logg('createHeader');

    if(!this.headerIsString)
    {
      await this.createHeaderString({ headers, options });
    } 
    else 
    {
      await this.createHeaderObject({ headers, options });
    }

    return Promise.resolve();
  }

  // Rows - tables.rows
  // ------------------------------------------------------------------

  createRowArray(data) 
  {
    this.logg('createRowArray');
    return new Promise( async (resolve, reject) => 
    {
      // local
      const { rows, options } = data;

      // has content
      if(!rows || !rows.length)
      {
        resolve();
        return;
      }

      // is array whith object
      if(!Array.isArray(rows[0]) || typeof rows[0][0] !== 'string')
      {
        reject();
        throw new Error('ROWS need be a Array[] with String"". See documentation.');
        return;
      }

      // variables
      const { top, right, bottom, left } = this.pdfkitTableCache.options.padding;
      let rowIndex, colIndex; // index
      let rowLen = rows.length || 0; // array lines
      let colLen = rows[0].length || 0; // array columns
      let elm; // element line
      let text;

      // loop lines
      for(rowIndex = 0; rowIndex < rowLen; rowIndex++) 
      {
        // row calc
        this.rowHeight = await this.calcRowHeightString(rows[rowIndex], { isHeader: false });

        // Switch to next page if we cannot go any further because the space is over.
        // For safety, consider 3 rows margin instead of just one
        // this.y + this.rowHeight + this.pdfkitTableCache.safelyMarginBottom >= this.pdfkitTableCache.safelyPageHeight
        if(this.limitCellOnPage(this.rowHeight))
        {
          // const { layout, size, margins } = this.page;
          // await this.addPage({ layout, size, margins });
          await this.addPageAsync();
        }

        // x reset 1o time
        this.positionX = this.initialPositionX;
        // element
        elm = rows[rowIndex];

        // loop columns
        for(colIndex = 0; colIndex < colLen; colIndex++) 
        {

          // fill cell
          this.createRowFill({ x: this.positionX, y: this.positionY, width: this.cellWidth, height: this.rowHeight }, colIndex % 2 ? 'grey' : 'green', 0.2);
          // style
          this.pdfkitTableCache.options.prepareRow(elm, colIndex, rowIndex, {}, {});

          // validade
          text = elm[colIndex];
          this.logg(text, colIndex);
          this.text(text, this.positionX + left, this.positionY + top,
          {
            width: this.cellWidth - (left + right),
            align: 'left',
          });

          // x add
          this.positionX += this.cellWidth;
        }

        // /!\ dont changer order
        // y add
        this.positionY += this.rowHeight;
        // x reset 2o time
        this.positionX = this.initialPositionX;
        // divider
        this.createDivider('horizontal', this.initialPositionX, this.positionY);
      }

      // x reset
      this.positionX = this.initialPositionX;
      // to global
      this.pdfkitTableCache.table.lines = rowLen;

      resolve(this);
    });
  }

  // Data - tables.datas
  // ------------------------------------------------------------------

  createRowObject(data) 
  {
    this.logg('createRowObject');
    return new Promise((resolve, reject) => 
    {
      // variables
      const { datas, headers } = data;

      // has content
      if(!datas || !datas.length)
      {
        resolve();
        return;
      }

      // is array whith object
      if(Array.isArray(datas[0]) || typeof datas[0] !== 'object')
      {
        reject();
        throw new Error('Datas need be a Array[] with Objects{}. See documentation.');
        return;
      }

      // loop
      datas.forEach((row, elIndex) => {
        this.logg(row);
        headers.forEach((col, heIndex) => {
          this.logg(col);
        });
      });

      // to global
      // this.pdfkitTableCache.table.lines = rowLen;

      resolve();
    });
  }



  // Calc row height (from array)
  // ------------------------------------------------------------------

  calcRowHeightString(row, { align, isHeader })
  {
    // criar um padding para header  ???/
    // cellp = this.prepareCellPadding(this.pdfkitTableCache.headers[i].padding || this.pdfkitTableCache.options.padding || 0);

    // validate
    isHeader === undefined && (isHeader = false);
    align || (align = 'left');

    // variables
    let text = '';
    let height = isHeader ? 0 : (this.pdfkitTableCache.minRowHeight || 0);
    let heightCompute = 0;
    let len = row.length || 0;
    let i = 0;

    // validate
    const { left, top, right, bottom } = this.pdfkitTableCache.options.padding;

    // loop
    for(i = 0; i < len; i++) 
    {
      // value
      text = row[i];
      text = String(text).replace('bold:','').replace('size','').replace(/^:/g,'');

      // calc height size of string
      heightCompute = this.heightOfString(text, 
      {
        width: this.cellWidth - (left + right),
        align,
      });
      
      // stay max height
      height = Math.max(height, heightCompute);
    }
    
    Promise.resolve(height + this.pdfkitTableCache.distanceCorrection + top + bottom);
  };

  // Calc row height (from object)
  // ------------------------------------------------------------------

  calcRowHeightObject(row, { align, isHeader })
  {
    let result = 0;
    let cellp;

    // if row is object, content with property and options
    if(!Array.isArray(row) && typeof row === 'object' && !row.hasOwnProperty('property')){
      const cells = []; 
      // get all properties names on header
      this.pdfkitTableCache.headers.forEach(({property}) => cells.push(row[property]) );
      // define row with properties header
      row = cells;
    }

    row.forEach((cell,i) => {
      let text = cell;
      // object
      // read cell and get label of object
      if( typeof cell === 'object' ){
        // define label
        text = String(cell.label);
        // apply font size on calc about height row 
        //cell.hasOwnProperty('options') && prepareRowOptions(cell);
      }

      text = String(text).replace('bold:','').replace('size','');

      // cell padding
      const { left, top, right, bottom } = this.pdfkitTableCache.headers[i].padding || this.pdfkitTableCache.options.padding || {};

      // calc height size of string
      const cellHeight = this.heightOfString(text, 
      {
        // width: columnSizes[i] - (cellp.left + cellp.right),
        width: this.cellWidth - (left + right),
        align: 'left',
      });

      result = Math.max(result, cellHeight);
    });

    return result; // + columnSpacing;
  }

  // Init loop
  // ------------------------------------------------------------------

  async createTable(data) 
  {
    this.logg('createTable');
    return new Promise(async (resolve, reject) => 
    {
      // variables
      const { table, options } = data;
        let { headers, datas, rows } = table;

      // lopps
      await this.createRowObject({ headers, datas, options });
      await this.createRowArray({ headers, rows, options });

      resolve(this);
    });
  }


  // Resume
  // ------------------------------------------------------------------

  tableResume() {
    return {
      ...this.pdfkitTableCache.table,
      y: this.positionY,
      x: this.positionX,  
    }
  }

  // Table - THE MAGIC
  // ------------------------------------------------------------------

  async table(table, options, callback) 
  {
    // prepare
    table   = this.prepareTable(table);
    options = this.prepareOptions(options);
    options = { ...options, ...table.options }; // merge options

    this.initCalcs();
    this.initValidates();
    
    // on fire
    this.on('pageAdded', this.pageAddedFire);

    // init
    this.logg('table');
    try 
    {
      await this.createHeader({ headers: table.headers, options });
      await this.createTable({ table, options });
      // break
      this.moveDown();
    } 
    catch (error) 
    {
      console.error(error);
      throw new Error(error);
    }

    // off fire
    this.off('pageAdded', this.pageAddedFire);

    // this.logg(resolve);
    typeof callback === 'function' && callback(this.tableResume());
    return Promise.resolve(this.tableResume());
  }

  // Join tables
  // ------------------------------------------------------------------

  async tables(tables, callback) {
    return new Promise( async (resolve, reject) => 
    {
      try 
      {
        if(Array.isArray(tables)) 
        {
          // many tables
          for(let i = 0; i < tables.length; i++) 
          {
            await this.table(tables[i], tables[i].options || {});
          }
        }
        else if(typeof tables === 'object') 
        {
          // else is tables is a unique table object
          await this.table(tables, tables.options || {});
        }
      
        // callback
        typeof callback === 'function' && callback(this.tableResume());
        // done!
        resolve(this.tableResume());
      } 
      catch (error) 
      {
        // ops!
        reject(error);
      }
    });
  }

  logg(...args) 
  {
    // console.log(args);
  }

}

module.exports = PDFDocumentWithTables;